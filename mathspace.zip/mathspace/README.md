# MathSpace 🧮

> **Không gian toán học hiện đại** cho học sinh THPT và sinh viên đại học.  
> A modern math workspace for high-school and university students.

[![TypeScript](https://img.shields.io/badge/TypeScript-5.8-blue.svg)](https://www.typescriptlang.org/)
[![Next.js](https://img.shields.io/badge/Next.js-15-black.svg)](https://nextjs.org/)
[![React](https://img.shields.io/badge/React-19-61DAFB.svg)](https://react.dev/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## ✨ Tính năng (Features)

| Công cụ | Mô tả |
|---|---|
| 📈 **Đồ thị** | Vẽ hàm số với Plotly.js — zoom, pan, tìm nghiệm, nhiều đồ thị cùng lúc |
| ↗↘ **Bảng biến thiên** | Tự động tính đạo hàm, điểm tới hạn và sinh bảng biến thiên SVG |
| ± **Bảng xét dấu** | Xét dấu đa thức, phân thức — phát hiện nghiệm và điểm không xác định |
| ∑ **Soạn công thức** | Editor LaTeX với KaTeX preview thời gian thực và bộ ký hiệu toán học |
| △ **Hình học** | Canvas tương tác — điểm, đoạn thẳng, đường tròn, tam giác, vector |
| ⊞ **Tạo bảng** | Bảng dữ liệu với ô toán học (LaTeX), gộp/tách ô, xuất LaTeX |

### Tính năng chung
- 🌐 **Đa ngôn ngữ**: Tiếng Việt & English (next-intl)
- 🌙 **Dark / Light mode**
- 💾 **Local-first**: Toàn bộ dữ liệu lưu trong IndexedDB (Dexie.js) — không server, offline hoàn toàn
- 📤 **Xuất file**: JSON, SVG, LaTeX, PNG, PDF
- ⌨️ **Phím tắt**: Ctrl+Z/Y, Ctrl+Shift+E, Ctrl+1-9
- 📱 **Responsive**: Desktop-first nhưng hỗ trợ mobile

---

## 🛠 Tech Stack

```
Framework:   Next.js 15 (App Router) + React 19
Language:    TypeScript 5 (strict mode)
Styling:     Tailwind CSS v4
UI:          Radix UI + custom components
State:       Zustand + Immer
Storage:     Dexie.js (IndexedDB wrapper)
Math:        mathjs (symbolic) + KaTeX (render) + Plotly.js (graph)
i18n:        next-intl v4
```

---

## 🚀 Cài đặt & Chạy (Setup & Run)

### Yêu cầu (Requirements)
- **Node.js** ≥ 18.17
- **npm** ≥ 9

### 1. Clone repository

```bash
git clone https://github.com/your-username/mathspace.git
cd mathspace
```

### 2. Cài đặt dependencies

```bash
npm install
```

### 3. Chạy development server

```bash
npm run dev
```

Mở [http://localhost:3000](http://localhost:3000) — tự động redirect đến `/vi` (hoặc `/en`).

### 4. Build production

```bash
npm run build
npm start
```

---

## 📁 Cấu trúc thư mục (Project Structure)

```
src/
├── app/
│   ├── layout.tsx              # Root layout (HTML shell)
│   └── [locale]/
│       ├── layout.tsx          # Locale layout (i18n + providers)
│       └── page.tsx            # Main app shell
│
├── components/
│   ├── layout/
│   │   ├── Toolbar.tsx         # Top bar (new, export, undo, theme, lang)
│   │   ├── Sidebar.tsx         # Left nav (tools + workspace list)
│   │   └── WorkspaceArea.tsx   # Tab system + lazy feature loading
│   ├── providers/
│   │   └── Providers.tsx       # Theme init + DB init
│   └── ui/
│       ├── button.tsx          # Button (CVA variants)
│       ├── primitives.tsx      # Input, Textarea, Label, Badge, Separator, Switch
│       └── composite.tsx       # Tooltip, Dialog, ScrollArea, Tabs
│
├── features/
│   ├── graph/
│   │   └── GraphTool.tsx       # Plotly.js graph with function list + analysis
│   ├── formula-editor/
│   │   ├── FormulaEditor.tsx   # KaTeX editor + history
│   │   └── components/
│   │       └── SymbolPicker.tsx # Categorized symbol picker
│   ├── variation-table/
│   │   └── VariationTable.tsx  # Bảng biến thiên tự động (SVG)
│   ├── sign-table/
│   │   └── SignTable.tsx       # Bảng xét dấu tự động
│   ├── geometry/
│   │   └── GeometryTool.tsx    # Canvas 2D (điểm, đoạn, đường, tròn...)
│   ├── table-editor/
│   │   └── TableEditor.tsx     # Bảng với math cells + LaTeX export
│   ├── export/
│   │   └── ExportDialog.tsx    # JSON, SVG, LaTeX, PNG, PDF
│   └── settings/
│       └── SettingsDialog.tsx  # Theme, language, clear data, shortcuts
│
├── hooks/
│   ├── use-db.ts               # IndexedDB auto-save sync hook
│   ├── use-theme.ts            # Dark/light/system theme toggle
│   └── use-hotkeys.ts          # Global keyboard shortcut registration
│
├── lib/
│   ├── db.ts                   # Dexie.js database singleton + API
│   ├── defaults.ts             # Default data factories for each workspace type
│   ├── utils.ts                # cn(), downloadFile(), generateId(), colors...
│   └── math/
│       ├── parser.ts           # mathjs evaluator, root finder, plot data gen
│       ├── variation-table.ts  # Bảng biến thiên computation + SVG export
│       └── sign-table.ts       # Bảng xét dấu computation + SVG export
│
├── store/
│   ├── workspace-store.ts      # Zustand workspace state (Immer)
│   └── ui-store.ts             # Zustand UI state (theme, sidebar)
│
├── types/
│   ├── index.ts                # All TypeScript types
│   └── plotly.d.ts             # Plotly module declaration
│
├── messages/
│   ├── vi.json                 # Tiếng Việt
│   └── en.json                 # English
│
└── i18n/
    ├── config.ts               # Locale routing config
    └── request.ts              # next-intl server request config
```

---

## 🌐 Định tuyến ngôn ngữ (i18n Routing)

| URL | Nội dung |
|-----|----------|
| `/` | Redirect → `/vi` |
| `/vi` | Tiếng Việt |
| `/en` | English |

Chuyển đổi ngôn ngữ bằng nút **"VI / EN"** trên toolbar.

---

## ⌨️ Phím tắt (Keyboard Shortcuts)

| Phím | Chức năng |
|------|-----------|
| `Ctrl+Z` | Hoàn tác (Undo) |
| `Ctrl+Y` | Làm lại (Redo) |
| `Ctrl+Shift+E` | Mở hộp xuất file |
| `Ctrl+1` đến `Ctrl+9` | Chuyển sang workspace tab 1–9 |
| `Alt+Drag` | Pan view (hình học / đồ thị) |
| `Scroll` | Zoom in/out (hình học) |
| `Enter` | Xác nhận hàm số / công thức |
| `Escape` | Hủy chỉnh sửa |
| `Delete` | Xóa hình đang chọn (hình học) |

---

## 💾 Lưu trữ dữ liệu (Data Storage)

Toàn bộ dữ liệu lưu **cục bộ** trong trình duyệt:

```
IndexedDB "MathSpaceDB"
├── workspaces    # Tất cả workspace data
└── sessions      # Trạng thái phiên hiện tại
```

**Không có server, không có cloud, không có tài khoản.**

Xóa tất cả dữ liệu: **Settings → Clear All Data**.

---

## 📤 Xuất file (Export)

| Định dạng | Mô tả | Công cụ hỗ trợ |
|-----------|-------|----------------|
| **JSON** | Dữ liệu workspace thô | Tất cả |
| **SVG** | Bảng biến thiên / xét dấu vector | BBT, BXD, Hình học |
| **LaTeX** | Mã nguồn LaTeX | Công thức, Bảng, Đồ thị |
| **PNG** | Canvas hình ảnh | Đồ thị, Hình học |
| **PDF** | In trang (browser print) | Tất cả |

---

## 🔧 Phát triển (Development)

### Thêm công cụ mới

1. Thêm `WorkspaceType` vào `src/types/index.ts`
2. Tạo interface data và factory trong `src/lib/defaults.ts`
3. Tạo feature component trong `src/features/your-tool/YourTool.tsx`
4. Đăng ký trong `WorkspaceArea.tsx` (lazy import + switch case)
5. Thêm icon và label trong `Sidebar.tsx`
6. Thêm bản dịch vào `src/messages/vi.json` và `en.json`

### Thêm ngôn ngữ mới

1. Thêm locale vào `src/i18n/config.ts`:
   ```ts
   locales: ['vi', 'en', 'ja'],
   ```
2. Tạo file `src/messages/ja.json` (copy từ `en.json`)
3. Dịch tất cả strings

### Scripts

```bash
npm run dev          # Development server
npm run build        # Production build
npm run start        # Production server
npm run lint         # ESLint
npm run typecheck    # TypeScript check
```

---

## 🚢 Triển khai (Deployment)

### Vercel (Khuyến nghị)

```bash
npx vercel
```

Không cần cấu hình thêm — next-intl và static export hoạt động out-of-the-box.

### Docker

```dockerfile
FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
COPY --from=builder /app/public ./public
EXPOSE 3000
CMD ["node", "server.js"]
```

```bash
docker build -t mathspace .
docker run -p 3000:3000 mathspace
```

### Static Export (Tùy chọn)

Thêm vào `next.config.ts`:
```ts
output: 'export',
```

```bash
npm run build
# Output: ./out/ (có thể host trên GitHub Pages, Netlify, S3...)
```

> **Lưu ý**: Static export không hỗ trợ server-side features của next-intl.  
> Sử dụng Vercel hoặc Node.js deployment để có đầy đủ tính năng i18n.

---

## 🔒 Bảo mật & Quyền riêng tư

- **Không thu thập dữ liệu**: Không analytics, không tracking
- **Không API keys**: Không gọi server nào
- **Offline first**: Hoạt động hoàn toàn không có internet sau lần tải đầu tiên
- **Dữ liệu thuộc về bạn**: Xóa trình duyệt = xóa tất cả

---

## 📝 License

MIT © MathSpace

---

*Được xây dựng với ❤️ cho học sinh toán Việt Nam*
