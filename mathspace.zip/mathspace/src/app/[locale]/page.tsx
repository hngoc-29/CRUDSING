import { Toolbar } from '@/components/layout/Toolbar';
import { Sidebar } from '@/components/layout/Sidebar';
import { WorkspaceArea } from '@/components/layout/WorkspaceArea';

export default function MainPage() {
  return (
    <div className="flex h-full flex-col overflow-hidden">
      <Toolbar />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <WorkspaceArea />
      </div>
    </div>
  );
}
