import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = {
  title: 'MathSpace – Không gian toán học',
  description:
    'Ứng dụng toán học hiện đại dành cho học sinh THPT và đại học. Vẽ đồ thị, tạo bảng biến thiên, xét dấu, hình học và soạn công thức toán học.',
  keywords: ['toán học', 'THPT', 'đồ thị', 'bảng biến thiên', 'hình học', 'LaTeX', 'KaTeX'],
  authors: [{ name: 'MathSpace Team' }],
  creator: 'MathSpace',
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    alternateLocale: 'en_US',
    title: 'MathSpace',
    description: 'Modern math workspace for high school and university students',
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html suppressHydrationWarning>
      <head />
      <body>{children}</body>
    </html>
  );
}
