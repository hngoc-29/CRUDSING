'use client';

import { useState } from 'react';
import {
  TrendingUp, Sigma, ArrowUpDown, Table2, Triangle,
  Settings, ChevronLeft, ChevronRight, Minus, X,
  MoreHorizontal, Copy, Pencil,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import { useWorkspaceStore } from '@/store/workspace-store';
import { useUIStore } from '@/store/ui-store';
import { Tooltip } from '@/components/ui/composite';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/composite';
import { Separator } from '@/components/ui/primitives';
import { cn } from '@/lib/utils';
import type { WorkspaceType, Workspace } from '@/types';
import * as DropdownMenu from '@radix-ui/react-dropdown-menu';
import { SettingsDialog } from '@/features/settings/SettingsDialog';

// ─── Tool Config ──────────────────────────────────────────────────────────────

interface ToolConfig {
  type: WorkspaceType;
  icon: React.ElementType;
  labelKey: string;
}

const TOOLS: ToolConfig[] = [
  { type: 'graph',           icon: TrendingUp,  labelKey: 'graph'           },
  { type: 'variation-table', icon: ArrowUpDown,  labelKey: 'variationTable'  },
  { type: 'sign-table',      icon: Minus,        labelKey: 'signTable'       },
  { type: 'formula',         icon: Sigma,        labelKey: 'formula'         },
  { type: 'geometry',        icon: Triangle,     labelKey: 'geometry'        },
  { type: 'table',           icon: Table2,       labelKey: 'tableEditor'     },
];

// ─── Workspace Item ───────────────────────────────────────────────────────────

function WorkspaceItem({
  workspace,
  isActive,
  collapsed,
}: {
  workspace: Workspace;
  isActive: boolean;
  collapsed: boolean;
}) {
  const t = useTranslations('sidebar');
  const tCommon = useTranslations('common');
  const { setActiveWorkspace, removeWorkspace, duplicateWorkspace, updateWorkspaceName } = useWorkspaceStore();
  const [editing, setEditing] = useState(false);
  const [nameValue, setNameValue] = useState(workspace.name);

  const toolConfig = TOOLS.find((tool) => tool.type === workspace.type);
  const Icon = toolConfig?.icon ?? TrendingUp;

  function commitRename() {
    setEditing(false);
    if (nameValue.trim()) {
      updateWorkspaceName(workspace.id, nameValue.trim());
    } else {
      setNameValue(workspace.name);
    }
  }

  const displayName = workspace.name || t(toolConfig?.labelKey as Parameters<typeof t>[0] ?? 'graph');

  if (collapsed) {
    return (
      <Tooltip content={displayName} side="right">
        <button
          onClick={() => setActiveWorkspace(workspace.id)}
          className={cn(
            'flex h-8 w-8 items-center justify-center rounded-md transition-colors mx-auto',
            isActive
              ? 'bg-primary/15 text-primary'
              : 'text-muted-foreground hover:bg-accent hover:text-foreground'
          )}
          aria-label={displayName}
        >
          <Icon className="h-4 w-4" />
        </button>
      </Tooltip>
    );
  }

  return (
    <div
      className={cn(
        'group flex h-8 cursor-pointer items-center gap-2 rounded-md px-2 text-sm transition-colors',
        isActive
          ? 'bg-primary/15 text-primary'
          : 'text-muted-foreground hover:bg-accent hover:text-foreground'
      )}
      onClick={() => setActiveWorkspace(workspace.id)}
    >
      <Icon className="h-3.5 w-3.5 shrink-0" />

      {editing ? (
        <input
          autoFocus
          value={nameValue}
          onChange={(e) => setNameValue(e.target.value)}
          onBlur={commitRename}
          onKeyDown={(e) => { if (e.key === 'Enter') commitRename(); if (e.key === 'Escape') { setEditing(false); setNameValue(workspace.name); } }}
          className="h-5 flex-1 min-w-0 bg-transparent text-xs focus:outline-none"
          onClick={(e) => e.stopPropagation()}
        />
      ) : (
        <span className="flex-1 truncate text-xs">{displayName}</span>
      )}

      <DropdownMenu.Root>
        <DropdownMenu.Trigger asChild>
          <button
            className="invisible ml-auto h-5 w-5 shrink-0 rounded-sm text-muted-foreground opacity-0 transition-opacity group-hover:visible group-hover:opacity-100 hover:bg-accent"
            onClick={(e) => e.stopPropagation()}
          >
            <MoreHorizontal className="h-3 w-3 mx-auto" />
          </button>
        </DropdownMenu.Trigger>
        <DropdownMenu.Portal>
          <DropdownMenu.Content
            className="z-50 min-w-[150px] overflow-hidden rounded-md border border-border bg-surface p-1 shadow-lg"
            sideOffset={4}
            align="start"
          >
            <DropdownMenu.Item
              onSelect={(e) => { e.preventDefault(); setEditing(true); }}
              className="flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-xs hover:bg-accent focus:bg-accent focus:outline-none"
            >
              <Pencil className="h-3 w-3" />
              {tCommon('rename')}
            </DropdownMenu.Item>
            <DropdownMenu.Item
              onSelect={() => duplicateWorkspace(workspace.id)}
              className="flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-xs hover:bg-accent focus:bg-accent focus:outline-none"
            >
              <Copy className="h-3 w-3" />
              {tCommon('duplicate')}
            </DropdownMenu.Item>
            <DropdownMenu.Separator className="my-1 h-px bg-border" />
            <DropdownMenu.Item
              onSelect={() => removeWorkspace(workspace.id)}
              className="flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-xs text-destructive hover:bg-destructive/10 focus:bg-destructive/10 focus:outline-none"
            >
              <X className="h-3 w-3" />
              {tCommon('delete')}
            </DropdownMenu.Item>
          </DropdownMenu.Content>
        </DropdownMenu.Portal>
      </DropdownMenu.Root>
    </div>
  );
}

// ─── Tool Button ──────────────────────────────────────────────────────────────

function ToolButton({
  tool,
  collapsed,
}: {
  tool: ToolConfig;
  collapsed: boolean;
}) {
  const t = useTranslations('sidebar');
  const { addWorkspace } = useWorkspaceStore();
  const label = t(tool.labelKey as Parameters<typeof t>[0]);

  const button = (
    <button
      onClick={() => addWorkspace(tool.type)}
      className={cn(
        'flex items-center gap-2.5 rounded-md px-2 py-1.5 text-sm text-muted-foreground transition-colors',
        'hover:bg-accent hover:text-foreground',
        collapsed ? 'w-8 h-8 justify-center mx-auto' : 'w-full'
      )}
      aria-label={label}
    >
      <tool.icon className="h-4 w-4 shrink-0" />
      {!collapsed && <span className="truncate text-xs font-medium">{label}</span>}
    </button>
  );

  if (collapsed) {
    return <Tooltip content={label} side="right">{button}</Tooltip>;
  }
  return button;
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

export function Sidebar() {
  const t = useTranslations('sidebar');
  const { sidebarCollapsed, toggleSidebar } = useUIStore();
  const { workspaces, activeWorkspaceId } = useWorkspaceStore();
  const [settingsOpen, setSettingsOpen] = useState(false);

  const collapsed = sidebarCollapsed;

  return (
    <>
      <aside
        className={cn(
          'sidebar-transition flex shrink-0 flex-col border-r border-border bg-surface',
          collapsed ? 'w-12' : 'w-52'
        )}
      >
        {/* Tools Section */}
        <div className={cn('p-2', collapsed && 'px-2')}>
          {!collapsed && (
            <p className="mb-1 px-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              {t('tools')}
            </p>
          )}
          <div className="flex flex-col gap-0.5">
            {TOOLS.map((tool) => (
              <ToolButton key={tool.type} tool={tool} collapsed={collapsed} />
            ))}
          </div>
        </div>

        <Separator />

        {/* Workspaces Section */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className={cn('p-2', collapsed && 'px-2')}>
              {!collapsed && workspaces.length > 0 && (
                <p className="mb-1 px-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                  {t('workspaces')}
                </p>
              )}
              <div className="flex flex-col gap-0.5">
                {workspaces.map((ws) => (
                  <WorkspaceItem
                    key={ws.id}
                    workspace={ws}
                    isActive={ws.id === activeWorkspaceId}
                    collapsed={collapsed}
                  />
                ))}
              </div>
            </div>
          </ScrollArea>
        </div>

        <Separator />

        {/* Bottom actions */}
        <div className={cn('flex items-center p-2', collapsed ? 'flex-col gap-1' : 'gap-1')}>
          <Tooltip content={t('settings')} side="right">
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={() => setSettingsOpen(true)}
              aria-label={t('settings')}
            >
              <Settings className="h-4 w-4" />
            </Button>
          </Tooltip>

          <div className="flex-1" />

          <Tooltip content={collapsed ? t('expand') : t('collapse')} side="right">
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={toggleSidebar}
              aria-label={collapsed ? t('expand') : t('collapse')}
            >
              {collapsed ? (
                <ChevronRight className="h-4 w-4" />
              ) : (
                <ChevronLeft className="h-4 w-4" />
              )}
            </Button>
          </Tooltip>
        </div>
      </aside>

      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
    </>
  );
}
