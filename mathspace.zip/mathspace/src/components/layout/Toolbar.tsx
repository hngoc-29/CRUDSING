'use client';

import { useState } from 'react';
import {
  Moon, Sun, Languages, Undo2, Redo2, Download,
  Plus, Save, FunctionSquare, ChevronDown,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import { useRouter, usePathname } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Tooltip } from '@/components/ui/composite';
import { Separator } from '@/components/ui/primitives';
import { useWorkspaceStore } from '@/store/workspace-store';
import { useUIStore } from '@/store/ui-store';
import { useTheme } from '@/hooks/use-theme';
import { useHotkeys, HOTKEYS } from '@/hooks/use-hotkeys';
import { ExportDialog } from '@/features/export/ExportDialog';
import type { WorkspaceType } from '@/types';
import * as DropdownMenu from '@radix-ui/react-dropdown-menu';
import { cn } from '@/lib/utils';

// ─── New Workspace Dropdown ────────────────────────────────────────────────────

const WORKSPACE_TYPES: Array<{ type: WorkspaceType; label: string; labelVi: string; icon: string }> = [
  { type: 'graph',           label: 'Graph',           labelVi: 'Đồ thị',           icon: '📈' },
  { type: 'formula',         label: 'Formula Editor',  labelVi: 'Soạn công thức',   icon: '∑' },
  { type: 'variation-table', label: 'Variation Table', labelVi: 'Bảng biến thiên',  icon: '↗↘' },
  { type: 'sign-table',      label: 'Sign Table',      labelVi: 'Bảng xét dấu',    icon: '±' },
  { type: 'geometry',        label: 'Geometry',        labelVi: 'Hình học',         icon: '△' },
  { type: 'table',           label: 'Table Editor',    labelVi: 'Tạo bảng',        icon: '⊞' },
];

function NewWorkspaceMenu({ locale }: { locale: string }) {
  const t = useTranslations('toolbar');
  const { addWorkspace } = useWorkspaceStore();

  return (
    <DropdownMenu.Root>
      <DropdownMenu.Trigger asChild>
        <Button variant="default" size="sm" className="gap-1.5">
          <Plus className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">{t('new')}</span>
          <ChevronDown className="h-3 w-3 opacity-60" />
        </Button>
      </DropdownMenu.Trigger>

      <DropdownMenu.Portal>
        <DropdownMenu.Content
          className={cn(
            'z-50 min-w-[180px] overflow-hidden rounded-lg border border-border bg-surface p-1 shadow-xl',
            'data-[state=open]:animate-in data-[state=closed]:animate-out',
            'data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0',
            'data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95'
          )}
          sideOffset={8}
          align="start"
        >
          {WORKSPACE_TYPES.map(({ type, label, labelVi, icon }) => (
            <DropdownMenu.Item
              key={type}
              onSelect={() => addWorkspace(type)}
              className={cn(
                'flex cursor-pointer items-center gap-2.5 rounded-md px-3 py-2 text-sm text-foreground',
                'hover:bg-accent focus:bg-accent focus:outline-none'
              )}
            >
              <span className="w-5 text-center text-base">{icon}</span>
              <span>{locale === 'vi' ? labelVi : label}</span>
            </DropdownMenu.Item>
          ))}
        </DropdownMenu.Content>
      </DropdownMenu.Portal>
    </DropdownMenu.Root>
  );
}

// ─── Toolbar ──────────────────────────────────────────────────────────────────

export function Toolbar() {
  const t = useTranslations('toolbar');
  const { toggleTheme, isDark } = useTheme();
  const [exportOpen, setExportOpen] = useState(false);
  const router = useRouter();
  const pathname = usePathname();

  // Extract current locale from pathname
  const locale = pathname.startsWith('/en') ? 'en' : 'vi';
  const otherLocale = locale === 'vi' ? 'en' : 'vi';

  function switchLocale() {
    const segments = pathname.split('/');
    segments[1] = otherLocale;
    router.push(segments.join('/') || `/${otherLocale}`);
  }

  // Keyboard shortcuts
  useHotkeys([
    HOTKEYS.ctrl('z', () => {/* handled per feature */}, 'Undo'),
    HOTKEYS.ctrl('y', () => {/* handled per feature */}, 'Redo'),
    HOTKEYS.ctrlShift('e', () => setExportOpen(true), 'Export'),
  ]);

  return (
    <>
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-border bg-surface px-3">
        {/* Brand */}
        <div className="flex items-center gap-2 min-w-0">
          <FunctionSquare className="h-5 w-5 text-primary shrink-0" />
          <span className="hidden text-sm font-semibold tracking-tight sm:block">{t('title')}</span>
        </div>

        <Separator orientation="vertical" className="mx-1 h-5" />

        {/* Primary actions */}
        <div className="flex items-center gap-1">
          <NewWorkspaceMenu locale={locale} />
        </div>

        <Separator orientation="vertical" className="mx-1 h-5" />

        {/* History */}
        <div className="flex items-center gap-0.5">
          <Tooltip content={`${t('undo')} (Ctrl+Z)`}>
            <Button variant="ghost" size="icon-sm" aria-label={t('undo')}>
              <Undo2 />
            </Button>
          </Tooltip>
          <Tooltip content={`${t('redo')} (Ctrl+Y)`}>
            <Button variant="ghost" size="icon-sm" aria-label={t('redo')}>
              <Redo2 />
            </Button>
          </Tooltip>
        </div>

        {/* Spacer */}
        <div className="flex-1" />

        {/* Secondary actions */}
        <div className="flex items-center gap-0.5">
          <Tooltip content={`${t('export')} (Ctrl+Shift+E)`}>
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={() => setExportOpen(true)}
              aria-label={t('export')}
            >
              <Download />
            </Button>
          </Tooltip>

          <Tooltip content={t('language')}>
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={switchLocale}
              aria-label={t('language')}
              className="gap-1 px-2 text-xs font-medium uppercase"
            >
              <Languages className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{otherLocale}</span>
            </Button>
          </Tooltip>

          <Tooltip content={t('theme')}>
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={toggleTheme}
              aria-label={t('theme')}
            >
              {isDark ? <Sun /> : <Moon />}
            </Button>
          </Tooltip>
        </div>
      </header>

      <ExportDialog open={exportOpen} onOpenChange={setExportOpen} />
    </>
  );
}
