'use client';

import { useCallback, useEffect, lazy, Suspense } from 'react';
import { X, TrendingUp, Sigma, ArrowUpDown, Minus, Triangle, Table2 } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { useWorkspaceStore } from '@/store/workspace-store';
import { ScrollArea } from '@/components/ui/composite';
import { cn } from '@/lib/utils';
import type { Workspace, WorkspaceType } from '@/types';

// ─── Lazy Feature Components ──────────────────────────────────────────────────

const GraphTool         = lazy(() => import('@/features/graph/GraphTool').then((m) => ({ default: m.GraphTool })));
const FormulaEditor     = lazy(() => import('@/features/formula-editor/FormulaEditor').then((m) => ({ default: m.FormulaEditor })));
const VariationTable    = lazy(() => import('@/features/variation-table/VariationTable').then((m) => ({ default: m.VariationTable })));
const SignTable         = lazy(() => import('@/features/sign-table/SignTable').then((m) => ({ default: m.SignTable })));
const GeometryTool      = lazy(() => import('@/features/geometry/GeometryTool').then((m) => ({ default: m.GeometryTool })));
const TableEditor       = lazy(() => import('@/features/table-editor/TableEditor').then((m) => ({ default: m.TableEditor })));

// ─── Feature Resolver ─────────────────────────────────────────────────────────

function WorkspaceFeature({ workspace }: { workspace: Workspace }) {
  switch (workspace.type) {
    case 'graph':
      return <GraphTool workspace={workspace as Workspace<'graph'>} />;
    case 'formula':
      return <FormulaEditor workspace={workspace as Workspace<'formula'>} />;
    case 'variation-table':
      return <VariationTable workspace={workspace as Workspace<'variation-table'>} />;
    case 'sign-table':
      return <SignTable workspace={workspace as Workspace<'sign-table'>} />;
    case 'geometry':
      return <GeometryTool workspace={workspace as Workspace<'geometry'>} />;
    case 'table':
      return <TableEditor workspace={workspace as Workspace<'table'>} />;
    default:
      return null;
  }
}

// ─── Loading Skeleton ─────────────────────────────────────────────────────────

function FeatureLoader() {
  return (
    <div className="flex h-full items-center justify-center">
      <div className="flex flex-col items-center gap-3">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-border border-t-primary" />
        <p className="text-sm text-muted-foreground">Loading…</p>
      </div>
    </div>
  );
}

// ─── Tab Icons ────────────────────────────────────────────────────────────────

const TAB_ICONS: Record<WorkspaceType, React.ElementType> = {
  graph: TrendingUp,
  formula: Sigma,
  'variation-table': ArrowUpDown,
  'sign-table': Minus,
  geometry: Triangle,
  table: Table2,
};

const TYPE_KEY_MAP: Record<WorkspaceType, string> = {
  graph: 'graph',
  formula: 'formula',
  'variation-table': 'variationTable',
  'sign-table': 'signTable',
  geometry: 'geometry',
  table: 'tableEditor',
};

// ─── Workspace Tab ────────────────────────────────────────────────────────────

function WorkspaceTab({
  workspace,
  isActive,
  onSelect,
  onClose,
}: {
  workspace: Workspace;
  isActive: boolean;
  onSelect: () => void;
  onClose: (e: React.MouseEvent) => void;
}) {
  const t = useTranslations('sidebar');
  const typeKey = TYPE_KEY_MAP[workspace.type] as Parameters<typeof t>[0];
  const Icon = TAB_ICONS[workspace.type] ?? TrendingUp;
  const label = workspace.name || t(typeKey);

  return (
    <div
      role="tab"
      aria-selected={isActive}
      onClick={onSelect}
      className={cn(
        'group flex h-9 min-w-[120px] max-w-[180px] shrink-0 cursor-pointer items-center gap-1.5 border-r border-border px-3 text-sm transition-colors select-none',
        isActive
          ? 'bg-background text-foreground'
          : 'bg-surface text-muted-foreground hover:bg-accent hover:text-foreground'
      )}
    >
      <Icon className="h-3.5 w-3.5 shrink-0" />
      <span className="min-w-0 flex-1 truncate text-xs">{label}</span>
      <button
        onClick={onClose}
        className="invisible ml-1 h-4 w-4 shrink-0 rounded-sm opacity-0 transition-opacity group-hover:visible group-hover:opacity-100 hover:bg-muted"
        aria-label="Close"
      >
        <X className="h-3 w-3 mx-auto" />
      </button>
    </div>
  );
}

// ─── Empty State ──────────────────────────────────────────────────────────────

function EmptyState() {
  const t = useTranslations('workspace');

  return (
    <div className="flex h-full flex-col items-center justify-center gap-4 workspace-grid">
      <div className="flex flex-col items-center gap-2 rounded-xl border border-border bg-surface/80 p-8 text-center backdrop-blur-sm max-w-sm">
        <div className="rounded-full bg-primary/10 p-3">
          <TrendingUp className="h-6 w-6 text-primary" />
        </div>
        <h2 className="text-base font-semibold">{t('empty')}</h2>
        <p className="text-sm text-muted-foreground">{t('emptyDescription')}</p>
      </div>
    </div>
  );
}

// ─── WorkspaceArea ────────────────────────────────────────────────────────────

export function WorkspaceArea() {
  const { workspaces, activeWorkspaceId, setActiveWorkspace, removeWorkspace } = useWorkspaceStore();

  const activeWorkspace = workspaces.find((w) => w.id === activeWorkspaceId);

  const handleClose = useCallback(
    (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      removeWorkspace(id);
    },
    [removeWorkspace]
  );

  // Keyboard navigation for tabs
  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key >= '1' && e.key <= '9') {
        const idx = parseInt(e.key, 10) - 1;
        const ws = workspaces[idx];
        if (ws) {
          e.preventDefault();
          setActiveWorkspace(ws.id);
        }
      }
    }
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [workspaces, setActiveWorkspace]);

  return (
    <div className="flex flex-1 flex-col overflow-hidden bg-background">
      {/* Tab bar */}
      {workspaces.length > 0 && (
        <div className="flex h-9 shrink-0 items-stretch overflow-x-auto border-b border-border bg-surface">
          {workspaces.map((ws) => (
            <WorkspaceTab
              key={ws.id}
              workspace={ws}
              isActive={ws.id === activeWorkspaceId}
              onSelect={() => setActiveWorkspace(ws.id)}
              onClose={(e) => handleClose(e, ws.id)}
            />
          ))}
        </div>
      )}

      {/* Feature area */}
      <div className="flex-1 overflow-hidden">
        {activeWorkspace ? (
          <Suspense fallback={<FeatureLoader />}>
            <WorkspaceFeature workspace={activeWorkspace} />
          </Suspense>
        ) : (
          <EmptyState />
        )}
      </div>
    </div>
  );
}
