'use client';

import { type ReactNode, useEffect } from 'react';
import { useTheme } from '@/hooks/use-theme';
import { useDb } from '@/hooks/use-db';

// ─── Inner Providers (client) ─────────────────────────────────────────────────

function ThemeInitializer() {
  useTheme();
  useDb();
  return null;
}

// ─── Providers ────────────────────────────────────────────────────────────────

export function Providers({ children }: { children: ReactNode }) {
  return (
    <>
      <ThemeInitializer />
      {children}
    </>
  );
}
