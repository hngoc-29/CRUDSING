'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import { Copy, Check, BookOpen, MonitorPlay, AlignLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/primitives';
import { Label } from '@/components/ui/primitives';
import { ScrollArea } from '@/components/ui/composite';
import { Tooltip } from '@/components/ui/composite';
import { useWorkspaceStore } from '@/store/workspace-store';
import { cn } from '@/lib/utils';
import type { Workspace, FormulaWorkspaceData } from '@/types';
import { SymbolPicker } from './components/SymbolPicker';

// ─── KaTeX Renderer ───────────────────────────────────────────────────────────

function KaTeXPreview({ latex, displayMode }: { latex: string; displayMode: boolean }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function render() {
      if (!containerRef.current) return;
      try {
        const katex = (await import('katex')).default;
        katex.render(latex || '\\text{…}', containerRef.current, {
          displayMode,
          throwOnError: true,
          strict: false,
          trust: false,
          output: 'html',
        });
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'LaTeX error');
        if (containerRef.current) {
          containerRef.current.textContent = latex;
        }
      }
    }
    void render();
  }, [latex, displayMode]);

  return (
    <div
      ref={containerRef}
      className={cn(
        'min-h-[80px] w-full overflow-x-auto rounded-lg border border-border bg-surface-2 p-4 transition-colors',
        'font-serif text-foreground',
        error && 'border-destructive/50 text-destructive',
        displayMode && 'flex items-center justify-center'
      )}
    />
  );
}

// ─── History Item ─────────────────────────────────────────────────────────────

function HistoryItem({ latex, onRestore }: { latex: string; onRestore: (l: string) => void }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    async function render() {
      if (!containerRef.current || !latex) return;
      try {
        const katex = (await import('katex')).default;
        katex.render(latex, containerRef.current, {
          displayMode: false,
          throwOnError: false,
          output: 'html',
        });
      } catch {
        if (containerRef.current) containerRef.current.textContent = latex;
      }
    }
    void render();
  }, [latex]);

  return (
    <button
      onClick={() => onRestore(latex)}
      className="w-full rounded-md border border-border bg-surface p-2 text-left transition-colors hover:bg-accent overflow-hidden"
    >
      <div ref={containerRef} className="truncate text-xs text-foreground pointer-events-none" />
    </button>
  );
}

// ─── FormulaEditor ────────────────────────────────────────────────────────────

interface FormulaEditorProps {
  workspace: Workspace<'formula'>;
}

export function FormulaEditor({ workspace }: FormulaEditorProps) {
  const t = useTranslations('features.formula');
  const { updateWorkspaceData } = useWorkspaceStore();
  const data: FormulaWorkspaceData = workspace.data;

  const [copied, setCopied] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const updateData = useCallback(
    (patch: Partial<FormulaWorkspaceData>) => {
      updateWorkspaceData(workspace.id, { ...data, ...patch });
    },
    [workspace.id, data, updateWorkspaceData]
  );

  function handleLatexChange(value: string) {
    updateData({ latex: value });
  }

  function handleSaveToHistory() {
    if (!data.latex.trim()) return;
    const history = [data.latex, ...data.history.filter((h) => h !== data.latex)].slice(0, 20);
    updateData({ history });
  }

  function insertSymbol(symbol: string) {
    const ta = textareaRef.current;
    if (!ta) return;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const newVal = data.latex.slice(0, start) + symbol + data.latex.slice(end);
    updateData({ latex: newVal });

    requestAnimationFrame(() => {
      ta.focus();
      const pos = start + symbol.length;
      ta.setSelectionRange(pos, pos);
    });
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(data.latex);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  }

  return (
    <div className="feature-panel">
      {/* Header */}
      <div className="flex h-10 shrink-0 items-center gap-2 border-b border-border bg-surface px-4">
        <span className="text-sm font-medium">{t('title')}</span>
        <div className="flex-1" />
        <Tooltip content={t('displayMode')}>
          <Button
            variant={data.displayMode ? 'secondary' : 'ghost'}
            size="icon-sm"
            onClick={() => updateData({ displayMode: true })}
            aria-label={t('displayMode')}
          >
            <MonitorPlay className="h-3.5 w-3.5" />
          </Button>
        </Tooltip>
        <Tooltip content={t('inlineMode')}>
          <Button
            variant={!data.displayMode ? 'secondary' : 'ghost'}
            size="icon-sm"
            onClick={() => updateData({ displayMode: false })}
            aria-label={t('inlineMode')}
          >
            <AlignLeft className="h-3.5 w-3.5" />
          </Button>
        </Tooltip>
        <Button variant="outline" size="sm" onClick={handleCopy} className="gap-1.5">
          {copied ? <Check className="h-3.5 w-3.5 text-success" /> : <Copy className="h-3.5 w-3.5" />}
          {copied ? t('copied') : t('copy')}
        </Button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left: editor + preview */}
        <div className="flex flex-1 flex-col gap-0 overflow-hidden">
          {/* Preview */}
          <div className="border-b border-border p-4">
            <Label className="mb-2 block">{t('preview')}</Label>
            <KaTeXPreview latex={data.latex} displayMode={data.displayMode} />
          </div>

          {/* LaTeX Input */}
          <div className="flex flex-1 flex-col gap-2 p-4">
            <div className="flex items-center justify-between">
              <Label>{t('inputLabel')}</Label>
              <Tooltip content="Save to history">
                <Button variant="ghost" size="icon-sm" onClick={handleSaveToHistory}>
                  <BookOpen className="h-3.5 w-3.5" />
                </Button>
              </Tooltip>
            </div>
            <Textarea
              ref={textareaRef}
              value={data.latex}
              onChange={(e) => handleLatexChange(e.target.value)}
              placeholder={t('placeholder')}
              className="flex-1 resize-none font-mono text-sm leading-relaxed"
              rows={6}
              spellCheck={false}
              autoComplete="off"
            />
          </div>

          {/* History */}
          {data.history.length > 0 && (
            <div className="border-t border-border p-4">
              <div className="mb-2 flex items-center justify-between">
                <Label>{t('history')}</Label>
                <Button variant="ghost" size="sm" onClick={() => updateData({ history: [] })}>
                  {t('clearHistory')}
                </Button>
              </div>
              <ScrollArea className="h-28">
                <div className="flex flex-col gap-1 pr-2">
                  {data.history.map((item, idx) => (
                    <HistoryItem
                      key={idx}
                      latex={item}
                      onRestore={(l) => updateData({ latex: l })}
                    />
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}
        </div>

        {/* Right: Symbol Picker */}
        <div className="w-64 shrink-0 border-l border-border">
          <SymbolPicker onInsert={insertSymbol} />
        </div>
      </div>
    </div>
  );
}
