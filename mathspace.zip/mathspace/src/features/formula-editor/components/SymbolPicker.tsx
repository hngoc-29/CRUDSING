'use client';

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { ScrollArea } from '@/components/ui/composite';
import { Tooltip } from '@/components/ui/composite';
import { cn } from '@/lib/utils';

// ─── Symbol Data ──────────────────────────────────────────────────────────────

interface SymbolEntry {
  latex: string;
  display: string;
  description: string;
}

interface SymbolCategory {
  key: string;
  symbols: SymbolEntry[];
}

const SYMBOL_CATEGORIES: SymbolCategory[] = [
  {
    key: 'operators',
    symbols: [
      { latex: '+', display: '+', description: 'Plus' },
      { latex: '-', display: '−', description: 'Minus' },
      { latex: '\\times', display: '×', description: 'Times' },
      { latex: '\\div', display: '÷', description: 'Divide' },
      { latex: '\\pm', display: '±', description: 'Plus-minus' },
      { latex: '\\mp', display: '∓', description: 'Minus-plus' },
      { latex: '\\cdot', display: '·', description: 'Dot product' },
      { latex: '\\frac{a}{b}', display: 'a/b', description: 'Fraction' },
      { latex: '^{2}', display: 'x²', description: 'Squared' },
      { latex: '^{n}', display: 'xⁿ', description: 'Power' },
      { latex: '\\sqrt{}', display: '√', description: 'Square root' },
      { latex: '\\sqrt[n]{}', display: 'ⁿ√', description: 'nth root' },
      { latex: '|x|', display: '|x|', description: 'Absolute value' },
      { latex: '\\binom{n}{k}', display: 'C(n,k)', description: 'Binomial' },
    ],
  },
  {
    key: 'relations',
    symbols: [
      { latex: '=', display: '=', description: 'Equals' },
      { latex: '\\neq', display: '≠', description: 'Not equal' },
      { latex: '<', display: '<', description: 'Less than' },
      { latex: '>', display: '>', description: 'Greater than' },
      { latex: '\\leq', display: '≤', description: 'Less or equal' },
      { latex: '\\geq', display: '≥', description: 'Greater or equal' },
      { latex: '\\approx', display: '≈', description: 'Approximately' },
      { latex: '\\sim', display: '∼', description: 'Similar' },
      { latex: '\\equiv', display: '≡', description: 'Equivalent' },
      { latex: '\\propto', display: '∝', description: 'Proportional' },
    ],
  },
  {
    key: 'calculus',
    symbols: [
      { latex: '\\int', display: '∫', description: 'Integral' },
      { latex: '\\int_{a}^{b}', display: '∫ᵃᵇ', description: 'Definite integral' },
      { latex: '\\iint', display: '∬', description: 'Double integral' },
      { latex: '\\oint', display: '∮', description: 'Contour integral' },
      { latex: '\\sum_{i=1}^{n}', display: '∑', description: 'Sum' },
      { latex: '\\prod_{i=1}^{n}', display: '∏', description: 'Product' },
      { latex: '\\lim_{x\\to a}', display: 'lim', description: 'Limit' },
      { latex: '\\lim_{x\\to\\infty}', display: 'lim∞', description: 'Limit at infinity' },
      { latex: "f'(x)", display: "f′", description: 'First derivative' },
      { latex: "f''(x)", display: "f″", description: 'Second derivative' },
      { latex: '\\frac{dy}{dx}', display: 'dy/dx', description: 'Leibniz notation' },
      { latex: '\\frac{d^2y}{dx^2}', display: 'd²y/dx²', description: 'Second derivative' },
      { latex: '\\partial', display: '∂', description: 'Partial derivative' },
      { latex: '\\nabla', display: '∇', description: 'Nabla' },
      { latex: '\\infty', display: '∞', description: 'Infinity' },
    ],
  },
  {
    key: 'greekLetters',
    symbols: [
      { latex: '\\alpha', display: 'α', description: 'Alpha' },
      { latex: '\\beta', display: 'β', description: 'Beta' },
      { latex: '\\gamma', display: 'γ', description: 'Gamma' },
      { latex: '\\delta', display: 'δ', description: 'Delta' },
      { latex: '\\epsilon', display: 'ε', description: 'Epsilon' },
      { latex: '\\varepsilon', display: 'ε', description: 'Varepsilon' },
      { latex: '\\zeta', display: 'ζ', description: 'Zeta' },
      { latex: '\\eta', display: 'η', description: 'Eta' },
      { latex: '\\theta', display: 'θ', description: 'Theta' },
      { latex: '\\lambda', display: 'λ', description: 'Lambda' },
      { latex: '\\mu', display: 'μ', description: 'Mu' },
      { latex: '\\pi', display: 'π', description: 'Pi' },
      { latex: '\\sigma', display: 'σ', description: 'Sigma' },
      { latex: '\\Sigma', display: 'Σ', description: 'Sigma (upper)' },
      { latex: '\\phi', display: 'φ', description: 'Phi' },
      { latex: '\\omega', display: 'ω', description: 'Omega' },
      { latex: '\\Omega', display: 'Ω', description: 'Omega (upper)' },
      { latex: '\\Delta', display: 'Δ', description: 'Delta (upper)' },
      { latex: '\\Pi', display: 'Π', description: 'Pi (upper)' },
      { latex: '\\Lambda', display: 'Λ', description: 'Lambda (upper)' },
    ],
  },
  {
    key: 'sets',
    symbols: [
      { latex: '\\in', display: '∈', description: 'Element of' },
      { latex: '\\notin', display: '∉', description: 'Not element of' },
      { latex: '\\subset', display: '⊂', description: 'Subset' },
      { latex: '\\subseteq', display: '⊆', description: 'Subset or equal' },
      { latex: '\\supset', display: '⊃', description: 'Superset' },
      { latex: '\\cup', display: '∪', description: 'Union' },
      { latex: '\\cap', display: '∩', description: 'Intersection' },
      { latex: '\\emptyset', display: '∅', description: 'Empty set' },
      { latex: '\\setminus', display: '\\', description: 'Set difference' },
      { latex: '\\mathbb{R}', display: 'ℝ', description: 'Real numbers' },
      { latex: '\\mathbb{N}', display: 'ℕ', description: 'Natural numbers' },
      { latex: '\\mathbb{Z}', display: 'ℤ', description: 'Integers' },
      { latex: '\\mathbb{Q}', display: 'ℚ', description: 'Rationals' },
      { latex: '\\mathbb{C}', display: 'ℂ', description: 'Complex numbers' },
      { latex: '\\forall', display: '∀', description: 'For all' },
      { latex: '\\exists', display: '∃', description: 'There exists' },
    ],
  },
  {
    key: 'arrows',
    symbols: [
      { latex: '\\to', display: '→', description: 'Arrow right' },
      { latex: '\\leftarrow', display: '←', description: 'Arrow left' },
      { latex: '\\leftrightarrow', display: '↔', description: 'Bidirectional' },
      { latex: '\\Rightarrow', display: '⇒', description: 'Implies' },
      { latex: '\\Leftarrow', display: '⇐', description: 'Implied by' },
      { latex: '\\Leftrightarrow', display: '⟺', description: 'Iff' },
      { latex: '\\nearrow', display: '↗', description: 'NE arrow (increasing)' },
      { latex: '\\searrow', display: '↘', description: 'SE arrow (decreasing)' },
      { latex: '\\uparrow', display: '↑', description: 'Up arrow' },
      { latex: '\\downarrow', display: '↓', description: 'Down arrow' },
    ],
  },
];

// ─── Symbol Button ────────────────────────────────────────────────────────────

function SymbolButton({ symbol, onInsert }: { symbol: SymbolEntry; onInsert: (l: string) => void }) {
  return (
    <Tooltip content={`${symbol.description}: ${symbol.latex}`} side="top" delayDuration={300}>
      <button
        onClick={() => onInsert(symbol.latex)}
        className={cn(
          'flex h-8 w-8 items-center justify-center rounded-md border border-transparent',
          'text-sm font-medium text-foreground transition-colors',
          'hover:border-border hover:bg-accent'
        )}
      >
        {symbol.display}
      </button>
    </Tooltip>
  );
}

// ─── SymbolPicker ─────────────────────────────────────────────────────────────

interface SymbolPickerProps {
  onInsert: (latex: string) => void;
}

export function SymbolPicker({ onInsert }: SymbolPickerProps) {
  const t = useTranslations('features.formula');
  const [activeCategory, setActiveCategory] = useState(SYMBOL_CATEGORIES[0]?.key ?? 'operators');

  const activeCat = SYMBOL_CATEGORIES.find((c) => c.key === activeCategory);

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-10 shrink-0 items-center border-b border-border px-3">
        <span className="text-xs font-medium text-muted-foreground">{t('symbols')}</span>
      </div>

      {/* Category tabs */}
      <div className="flex shrink-0 flex-wrap gap-1 border-b border-border p-2">
        {SYMBOL_CATEGORIES.map((cat) => (
          <button
            key={cat.key}
            onClick={() => setActiveCategory(cat.key)}
            className={cn(
              'rounded px-2 py-1 text-[10px] font-medium transition-colors',
              activeCategory === cat.key
                ? 'bg-primary/15 text-primary'
                : 'text-muted-foreground hover:bg-accent hover:text-foreground'
            )}
          >
            {t(cat.key as Parameters<typeof t>[0])}
          </button>
        ))}
      </div>

      {/* Symbol grid */}
      <ScrollArea className="flex-1">
        <div className="grid grid-cols-4 gap-1 p-2">
          {activeCat?.symbols.map((symbol) => (
            <SymbolButton key={symbol.latex} symbol={symbol} onInsert={onInsert} />
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
