'use client';

import {
  useRef, useEffect, useState, useCallback, useReducer,
} from 'react';
import { useTranslations } from 'next-intl';
import {
  MousePointer2, Circle, Minus, Triangle, Square,
  ArrowRight, Dot, Undo2, Redo2, Trash2, Grid3x3,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/primitives';
import { Label } from '@/components/ui/primitives';
import { Switch } from '@/components/ui/primitives';
import { Separator } from '@/components/ui/primitives';
import { Tooltip } from '@/components/ui/composite';
import { useWorkspaceStore } from '@/store/workspace-store';
import { cn, generateId, clamp } from '@/lib/utils';
import type {
  Workspace, GeometryWorkspaceData, GeometryShape, GeometryToolType,
  PointShape, LineShape, CircleShape, PolygonShape, VectorShape,
} from '@/types';

// ─── Canvas Renderer ──────────────────────────────────────────────────────────

const GRID_COLOR_LIGHT = 'rgba(100,100,120,0.12)';
const GRID_COLOR_DARK = 'rgba(200,200,220,0.08)';
const AXIS_COLOR = 'rgba(100,100,140,0.4)';
const SELECTION_COLOR = '#6366f1';

function worldToCanvas(
  wx: number, wy: number,
  vp: { x: number; y: number; scale: number },
  width: number, height: number
) {
  return {
    cx: width / 2 + (wx - vp.x) * vp.scale,
    cy: height / 2 - (wy - vp.y) * vp.scale,
  };
}

function canvasToWorld(
  cx: number, cy: number,
  vp: { x: number; y: number; scale: number },
  width: number, height: number
) {
  return {
    wx: (cx - width / 2) / vp.scale + vp.x,
    wy: -(cy - height / 2) / vp.scale + vp.y,
  };
}

function drawGrid(
  ctx: CanvasRenderingContext2D,
  vp: { x: number; y: number; scale: number },
  w: number, h: number,
  gridSize: number,
  isDark: boolean
) {
  const gridPx = gridSize * vp.scale;
  if (gridPx < 8) return;

  ctx.strokeStyle = isDark ? GRID_COLOR_DARK : GRID_COLOR_LIGHT;
  ctx.lineWidth = 0.5;

  const startX = Math.floor((0 - w / 2) / gridPx) * gridPx;
  const startY = Math.floor((0 - h / 2) / gridPx) * gridPx;

  for (let gx = startX; gx < w; gx += gridPx) {
    const x = w / 2 + (gx - vp.x * vp.scale);
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
  }
  for (let gy = startY; gy < h; gy += gridPx) {
    const y = h / 2 - (gy - vp.y * vp.scale);
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }
}

function drawAxes(
  ctx: CanvasRenderingContext2D,
  vp: { x: number; y: number; scale: number },
  w: number, h: number
) {
  const { cx: ox, cy: oy } = worldToCanvas(0, 0, vp, w, h);
  ctx.strokeStyle = AXIS_COLOR;
  ctx.lineWidth = 1.5;
  ctx.setLineDash([]);
  ctx.beginPath(); ctx.moveTo(0, oy); ctx.lineTo(w, oy); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(ox, 0); ctx.lineTo(ox, h); ctx.stroke();
}

function drawShape(
  ctx: CanvasRenderingContext2D,
  shape: GeometryShape,
  vp: { x: number; y: number; scale: number },
  w: number, h: number,
  isDark: boolean
) {
  ctx.save();
  ctx.strokeStyle = shape.color;
  ctx.fillStyle = shape.color;
  ctx.lineWidth = shape.selected ? 2.5 : 1.5;

  if (shape.selected) {
    ctx.shadowColor = SELECTION_COLOR;
    ctx.shadowBlur = 6;
  }

  switch (shape.type) {
    case 'point': {
      const pt = shape as PointShape;
      const { cx, cy } = worldToCanvas(pt.x, pt.y, vp, w, h);
      ctx.beginPath();
      ctx.arc(cx, cy, (pt.size ?? 4), 0, Math.PI * 2);
      ctx.fill();
      if (shape.label) {
        ctx.fillStyle = isDark ? '#e2e8f0' : '#1e293b';
        ctx.font = '12px serif';
        ctx.fillText(shape.label, cx + 8, cy - 8);
      }
      break;
    }
    case 'segment':
    case 'line':
    case 'ray': {
      const ln = shape as LineShape;
      const { cx: x1, cy: y1 } = worldToCanvas(ln.x1, ln.y1, vp, w, h);
      const { cx: x2, cy: y2 } = worldToCanvas(ln.x2, ln.y2, vp, w, h);

      let sx1 = x1, sy1 = y1, sx2 = x2, sy2 = y2;

      if (shape.type === 'line') {
        // Extend to canvas bounds
        const dx = x2 - x1; const dy = y2 - y1;
        const len = Math.sqrt(dx * dx + dy * dy) || 1;
        const ext = Math.max(w, h) * 2;
        sx1 = x1 - (dx / len) * ext; sy1 = y1 - (dy / len) * ext;
        sx2 = x2 + (dx / len) * ext; sy2 = y2 + (dy / len) * ext;
      } else if (shape.type === 'ray') {
        const dx = x2 - x1; const dy = y2 - y1;
        const len = Math.sqrt(dx * dx + dy * dy) || 1;
        const ext = Math.max(w, h) * 2;
        sx2 = x1 + (dx / len) * ext; sy2 = y1 + (dy / len) * ext;
      }

      ctx.beginPath(); ctx.moveTo(sx1, sy1); ctx.lineTo(sx2, sy2); ctx.stroke();
      break;
    }
    case 'vector': {
      const v = shape as VectorShape;
      const { cx: x1, cy: y1 } = worldToCanvas(v.x1, v.y1, vp, w, h);
      const { cx: x2, cy: y2 } = worldToCanvas(v.x2, v.y2, vp, w, h);
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      // Arrowhead
      const angle = Math.atan2(y2 - y1, x2 - x1);
      const al = 12, aw = Math.PI / 6;
      ctx.beginPath();
      ctx.moveTo(x2, y2);
      ctx.lineTo(x2 - al * Math.cos(angle - aw), y2 - al * Math.sin(angle - aw));
      ctx.lineTo(x2 - al * Math.cos(angle + aw), y2 - al * Math.sin(angle + aw));
      ctx.closePath();
      ctx.fill();
      break;
    }
    case 'circle': {
      const c = shape as CircleShape;
      const { cx, cy } = worldToCanvas(c.cx, c.cy, vp, w, h);
      const rPx = c.radius * vp.scale;
      ctx.beginPath();
      ctx.arc(cx, cy, rPx, 0, Math.PI * 2);
      ctx.globalAlpha = 0.15;
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.stroke();
      break;
    }
    case 'triangle':
    case 'polygon': {
      const poly = shape as PolygonShape;
      if (poly.points.length < 2) break;
      ctx.beginPath();
      const first = poly.points[0];
      if (!first) break;
      const { cx: fx, cy: fy } = worldToCanvas(first.x, first.y, vp, w, h);
      ctx.moveTo(fx, fy);
      for (const pt of poly.points.slice(1)) {
        const { cx, cy } = worldToCanvas(pt.x, pt.y, vp, w, h);
        ctx.lineTo(cx, cy);
      }
      ctx.closePath();
      ctx.globalAlpha = 0.1;
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.stroke();
      break;
    }
  }

  ctx.restore();
}

// ─── Canvas Component ─────────────────────────────────────────────────────────

interface CanvasState {
  shapes: GeometryShape[];
  history: GeometryShape[][];
  historyIndex: number;
}

type CanvasAction =
  | { type: 'ADD_SHAPE'; shape: GeometryShape }
  | { type: 'UPDATE_SHAPE'; id: string; patch: Partial<GeometryShape> }
  | { type: 'REMOVE_SHAPE'; id: string }
  | { type: 'SET_SHAPES'; shapes: GeometryShape[] }
  | { type: 'SELECT_SHAPE'; id: string | null }
  | { type: 'UNDO' }
  | { type: 'REDO' }
  | { type: 'CLEAR' };

function canvasReducer(state: CanvasState, action: CanvasAction): CanvasState {
  switch (action.type) {
    case 'ADD_SHAPE': {
      const shapes = [...state.shapes, action.shape];
      const history = state.history.slice(0, state.historyIndex + 1);
      return { shapes, history: [...history, state.shapes], historyIndex: history.length };
    }
    case 'UPDATE_SHAPE': {
      const shapes = state.shapes.map((s) =>
        s.id === action.id ? { ...s, ...action.patch } : s
      ) as GeometryShape[];
      return { ...state, shapes };
    }
    case 'SELECT_SHAPE': {
      const shapes = state.shapes.map((s) =>
        ({ ...s, selected: s.id === action.id }) as GeometryShape
      );
      return { ...state, shapes };
    }
    case 'REMOVE_SHAPE': {
      const shapes = state.shapes.filter((s) => s.id !== action.id);
      const history = state.history.slice(0, state.historyIndex + 1);
      return { shapes, history: [...history, state.shapes], historyIndex: history.length };
    }
    case 'SET_SHAPES':
      return { ...state, shapes: action.shapes };
    case 'CLEAR': {
      const history = state.history.slice(0, state.historyIndex + 1);
      return { shapes: [], history: [...history, state.shapes], historyIndex: history.length };
    }
    case 'UNDO': {
      if (state.historyIndex < 0) return state;
      const prev = state.history[state.historyIndex];
      return { shapes: prev ?? [], history: state.history, historyIndex: state.historyIndex - 1 };
    }
    case 'REDO': {
      if (state.historyIndex >= state.history.length - 1) return state;
      const next = state.history[state.historyIndex + 1];
      return { shapes: next ?? [], history: state.history, historyIndex: state.historyIndex + 1 };
    }
    default:
      return state;
  }
}

// ─── GeometryTool ─────────────────────────────────────────────────────────────

interface GeometryToolProps {
  workspace: Workspace<'geometry'>;
}

export function GeometryTool({ workspace }: GeometryToolProps) {
  const t = useTranslations('features.geometry');
  const { updateWorkspaceData } = useWorkspaceStore();
  const gData: GeometryWorkspaceData = workspace.data;

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const animRef = useRef<number>(0);

  const [activeTool, setActiveTool] = useState<GeometryToolType>('select');
  const [activeColor, setActiveColor] = useState('#6366f1');
  const [viewport, setViewport] = useState(gData.viewport);
  const [showGrid, setShowGrid] = useState(gData.showGrid);
  const [showAxes, setShowAxes] = useState(gData.showAxes);
  const [isDark, setIsDark] = useState(false);

  const [cs, dispatch] = useReducer(canvasReducer, {
    shapes: gData.shapes,
    history: [],
    historyIndex: -1,
  });

  // Detect dark mode
  useEffect(() => {
    const check = () => setIsDark(document.documentElement.classList.contains('dark'));
    check();
    const obs = new MutationObserver(check);
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    return () => obs.disconnect();
  }, []);

  // Drawing state (for multi-step tools)
  const drawingRef = useRef<{
    active: boolean;
    points: { wx: number; wy: number }[];
  }>({ active: false, points: [] });

  // Pan state
  const panRef = useRef<{ active: boolean; startX: number; startY: number; startVp: typeof viewport } | null>(null);

  // Save to store when shapes change
  useEffect(() => {
    updateWorkspaceData(workspace.id, { ...gData, shapes: cs.shapes, viewport, showGrid, showAxes });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cs.shapes, viewport, showGrid, showAxes]);

  // Render loop
  useEffect(() => {
    function render() {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (!canvas || !ctx) return;

      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      if (showGrid) drawGrid(ctx, viewport, w, h, gData.gridSize, isDark);
      if (showAxes) drawAxes(ctx, viewport, w, h);

      for (const shape of cs.shapes) {
        if (shape.visible) drawShape(ctx, shape, viewport, w, h, isDark);
      }

      animRef.current = requestAnimationFrame(render);
    }

    animRef.current = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animRef.current);
  }, [cs.shapes, viewport, showGrid, showAxes, isDark, gData.gridSize]);

  // Resize observer
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const ro = new ResizeObserver(([entry]) => {
      const { width, height } = entry?.contentRect ?? { width: 0, height: 0 };
      canvas.width = width;
      canvas.height = height;
    });
    ro.observe(container);
    return () => ro.disconnect();
  }, []);

  // ─── Interaction ────────────────────────────────────────────────────────────

  const getWorldPos = useCallback((e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { wx: 0, wy: 0 };
    const rect = canvas.getBoundingClientRect();
    return canvasToWorld(e.clientX - rect.left, e.clientY - rect.top, viewport, canvas.width, canvas.height);
  }, [viewport]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button === 1 || (e.button === 0 && e.altKey)) {
      // Middle click / alt+drag → pan
      panRef.current = { active: true, startX: e.clientX, startY: e.clientY, startVp: { ...viewport } };
      return;
    }

    const { wx, wy } = getWorldPos(e);

    if (activeTool === 'select') {
      // Hit test
      let found: string | null = null;
      for (const shape of [...cs.shapes].reverse()) {
        if (shape.type === 'point') {
          const pt = shape as PointShape;
          const canvas = canvasRef.current!;
          const { cx: scx, cy: scy } = worldToCanvas(pt.x, pt.y, viewport, canvas.width, canvas.height);
          const { cx: mcx, cy: mcy } = worldToCanvas(wx, wy, viewport, canvas.width, canvas.height);
          if (Math.hypot(scx - mcx, scy - mcy) < 10) { found = shape.id; break; }
        }
      }
      dispatch({ type: 'SELECT_SHAPE', id: found });
      return;
    }

    if (activeTool === 'point') {
      const shape: PointShape = {
        id: generateId(), type: 'point',
        x: wx, y: wy, size: 4,
        label: String.fromCharCode(65 + cs.shapes.filter((s) => s.type === 'point').length % 26),
        color: activeColor, visible: true, selected: false,
      };
      dispatch({ type: 'ADD_SHAPE', shape });
      return;
    }

    if (activeTool === 'segment' || activeTool === 'line' || activeTool === 'ray' || activeTool === 'vector') {
      const dr = drawingRef.current;
      if (!dr.active) {
        dr.active = true;
        dr.points = [{ wx, wy }];
      } else {
        const p1 = dr.points[0]!;
        const shapeType = activeTool === 'vector' ? 'vector' : activeTool;
        const shape: LineShape | VectorShape = {
          id: generateId(),
          type: shapeType as 'segment' | 'line' | 'ray' | 'vector',
          x1: p1.wx, y1: p1.wy, x2: wx, y2: wy,
          label: '', color: activeColor, visible: true, selected: false,
        };
        dispatch({ type: 'ADD_SHAPE', shape });
        dr.active = false;
        dr.points = [];
      }
      return;
    }

    if (activeTool === 'circle') {
      const dr = drawingRef.current;
      if (!dr.active) {
        dr.active = true;
        dr.points = [{ wx, wy }];
      } else {
        const center = dr.points[0]!;
        const r = Math.hypot(wx - center.wx, wy - center.wy);
        const shape: CircleShape = {
          id: generateId(), type: 'circle',
          cx: center.wx, cy: center.wy, radius: r,
          label: '', color: activeColor, visible: true, selected: false,
        };
        dispatch({ type: 'ADD_SHAPE', shape });
        dr.active = false;
        dr.points = [];
      }
      return;
    }

    if (activeTool === 'triangle') {
      const dr = drawingRef.current;
      dr.points.push({ wx, wy });
      if (dr.points.length === 3) {
        const shape: PolygonShape = {
          id: generateId(), type: 'triangle',
          points: dr.points.map((p) => ({ x: p.wx, y: p.wy })),
          label: '', color: activeColor, visible: true, selected: false,
        };
        dispatch({ type: 'ADD_SHAPE', shape });
        dr.active = false;
        dr.points = [];
      } else {
        dr.active = true;
      }
    }
  }, [activeTool, getWorldPos, viewport, cs.shapes, activeColor]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (panRef.current?.active) {
      const dx = (e.clientX - panRef.current.startX) / viewport.scale;
      const dy = (e.clientY - panRef.current.startY) / viewport.scale;
      setViewport((prev) => ({
        ...prev,
        x: panRef.current!.startVp.x - dx,
        y: panRef.current!.startVp.y + dy,
      }));
    }
  }, [viewport.scale]);

  const handleMouseUp = useCallback(() => {
    panRef.current = null;
  }, []);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.1 : 0.9;
    setViewport((prev) => ({
      ...prev,
      scale: clamp(prev.scale * factor, 0.1, 50),
    }));
  }, []);

  const tools: Array<{ type: GeometryToolType; Icon: React.ElementType; labelKey: string }> = [
    { type: 'select',  Icon: MousePointer2, labelKey: 'select'  },
    { type: 'point',   Icon: Dot,           labelKey: 'point'   },
    { type: 'segment', Icon: Minus,         labelKey: 'segment' },
    { type: 'line',    Icon: Minus,         labelKey: 'line'    },
    { type: 'ray',     Icon: ArrowRight,    labelKey: 'ray'     },
    { type: 'circle',  Icon: Circle,        labelKey: 'circle'  },
    { type: 'triangle',Icon: Triangle,      labelKey: 'triangle'},
    { type: 'polygon', Icon: Square,        labelKey: 'polygon' },
    { type: 'vector',  Icon: ArrowRight,    labelKey: 'vector'  },
  ];

  return (
    <div className="feature-panel flex-row">
      {/* Tool palette */}
      <div className="flex w-12 shrink-0 flex-col items-center gap-1 border-r border-border bg-surface py-2">
        {tools.map(({ type, Icon, labelKey }) => (
          <Tooltip key={type} content={t(`tools.${labelKey}` as Parameters<typeof t>[0])} side="right">
            <button
              onClick={() => { setActiveTool(type); drawingRef.current = { active: false, points: [] }; }}
              className={cn(
                'h-9 w-9 rounded-md flex items-center justify-center text-muted-foreground transition-colors',
                activeTool === type ? 'bg-primary/15 text-primary' : 'hover:bg-accent hover:text-foreground'
              )}
            >
              <Icon className="h-4 w-4" />
            </button>
          </Tooltip>
        ))}

        <Separator className="my-1" />

        <Tooltip content="Undo" side="right">
          <button
            onClick={() => dispatch({ type: 'UNDO' })}
            disabled={cs.historyIndex < 0}
            className="h-9 w-9 rounded-md flex items-center justify-center text-muted-foreground hover:bg-accent disabled:opacity-40"
          >
            <Undo2 className="h-4 w-4" />
          </button>
        </Tooltip>
        <Tooltip content="Redo" side="right">
          <button
            onClick={() => dispatch({ type: 'REDO' })}
            disabled={cs.historyIndex >= cs.history.length - 1}
            className="h-9 w-9 rounded-md flex items-center justify-center text-muted-foreground hover:bg-accent disabled:opacity-40"
          >
            <Redo2 className="h-4 w-4" />
          </button>
        </Tooltip>
        <Tooltip content={t('clear')} side="right">
          <button
            onClick={() => dispatch({ type: 'CLEAR' })}
            className="h-9 w-9 rounded-md flex items-center justify-center text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </Tooltip>
      </div>

      {/* Canvas */}
      <div
        ref={containerRef}
        className={cn('feature-canvas', activeTool === 'select' ? 'cursor-default' : 'cursor-crosshair')}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
      >
        <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
      </div>

      {/* Right settings panel */}
      <div className="flex w-44 shrink-0 flex-col gap-3 border-l border-border bg-surface p-3">
        <div className="space-y-3">
          <div>
            <Label className="mb-1.5 block">{t('properties.color')}</Label>
            <input
              type="color"
              value={activeColor}
              onChange={(e) => setActiveColor(e.target.value)}
              className="h-8 w-full cursor-pointer rounded border border-border bg-transparent"
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <Label>{t('grid')}</Label>
            <Switch checked={showGrid} onCheckedChange={setShowGrid} />
          </div>
          <div className="flex items-center justify-between">
            <Label>{t('axes')}</Label>
            <Switch checked={showAxes} onCheckedChange={setShowAxes} />
          </div>

          <Separator />

          <div className="space-y-1">
            <Label>Zoom: {viewport.scale.toFixed(1)}×</Label>
            <div className="flex gap-1">
              <Button variant="outline" size="sm" className="flex-1 px-2"
                onClick={() => setViewport((p) => ({ ...p, scale: clamp(p.scale * 1.2, 0.1, 50) }))}>
                +
              </Button>
              <Button variant="outline" size="sm" className="flex-1 px-2"
                onClick={() => setViewport((p) => ({ ...p, scale: clamp(p.scale * 0.8, 0.1, 50) }))}>
                −
              </Button>
            </div>
            <Button variant="ghost" size="sm" className="w-full text-xs"
              onClick={() => setViewport({ x: 0, y: 0, scale: 1 })}>
              Reset
            </Button>
          </div>

          <Separator />

          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground">{cs.shapes.length} shapes</p>
            <p className="text-[10px] text-muted-foreground">Alt+drag to pan</p>
            <p className="text-[10px] text-muted-foreground">Scroll to zoom</p>
          </div>
        </div>
      </div>
    </div>
  );
}
