'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { Plus, Trash2, Eye, EyeOff, RotateCcw, Search } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/primitives';
import { Label } from '@/components/ui/primitives';
import { Switch } from '@/components/ui/primitives';
import { ScrollArea, Tooltip } from '@/components/ui/composite';
import { Separator } from '@/components/ui/primitives';
import { Badge } from '@/components/ui/primitives';
import { useWorkspaceStore } from '@/store/workspace-store';
import {
  generatePlotData, findRoots, preprocessExpression,
  validateExpression, formatValue,
} from '@/lib/math/parser';
import { getNextColor, generateId, cn } from '@/lib/utils';
import type { Workspace, GraphWorkspaceData, GraphFunction } from '@/types';

// Type for Plotly module loaded dynamically
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type PlotlyModule = any;

function PlotlyCanvas({
  data,
  onViewportChange,
}: {
  data: GraphWorkspaceData;
  onViewportChange: (vp: GraphWorkspaceData['viewport']) => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const plotRef = useRef<boolean>(false);

  useEffect(() => {
    async function renderPlot() {
      if (!containerRef.current) return;
      const Plotly: PlotlyModule = await import('plotly.js-dist-min');
      const { xMin, xMax, yMin, yMax } = data.viewport;
      const traces = [];

      for (const fn of data.functions) {
        if (!fn.visible || !fn.expression.trim()) continue;
        try {
          const expr = preprocessExpression(fn.expression);
          const { valid } = validateExpression(expr);
          if (!valid) continue;
          const segments = generatePlotData(expr, xMin, xMax, 600);
          for (const seg of segments) {
            traces.push({
              x: seg.x, y: seg.y, type: 'scatter', mode: 'lines',
              name: `y = ${fn.expression}`,
              line: { color: fn.color, width: fn.lineWidth,
                dash: fn.lineStyle === 'dashed' ? 'dash' : fn.lineStyle === 'dotted' ? 'dot' : 'solid' },
              connectgaps: false,
              showlegend: data.showLegend && segments.indexOf(seg) === 0,
            });
          }
        } catch { /* skip invalid */ }
      }

      const layout = {
        paper_bgcolor: 'transparent', plot_bgcolor: 'transparent',
        margin: { l: 50, r: 20, t: 20, b: 50 },
        xaxis: { range: [xMin, xMax], showgrid: data.showGrid,
          gridcolor: 'rgba(128,128,128,0.15)', zeroline: data.showAxes,
          zerolinecolor: 'rgba(128,128,128,0.5)', zerolinewidth: 1.5,
          color: 'rgba(180,180,200,0.8)', linecolor: 'rgba(128,128,128,0.3)' },
        yaxis: { range: [yMin, yMax], showgrid: data.showGrid,
          gridcolor: 'rgba(128,128,128,0.15)', zeroline: data.showAxes,
          zerolinecolor: 'rgba(128,128,128,0.5)', zerolinewidth: 1.5,
          color: 'rgba(180,180,200,0.8)', linecolor: 'rgba(128,128,128,0.3)' },
        legend: { font: { color: 'rgba(180,180,200,0.9)', size: 11 },
          bgcolor: 'rgba(0,0,0,0.3)', bordercolor: 'rgba(128,128,128,0.2)', borderwidth: 1 },
        showlegend: data.showLegend, dragmode: 'pan',
        font: { color: 'rgba(180,180,200,0.9)' },
      };

      const config = {
        responsive: true, displayModeBar: true,
        modeBarButtonsToRemove: ['toImage', 'sendDataToCloud'],
        displaylogo: false, scrollZoom: true,
      };

      if (!plotRef.current) {
        await Plotly.newPlot(containerRef.current, traces, layout, config);
        plotRef.current = true;
        // Use type assertion for event listener
        (containerRef.current as unknown as { on: (event: string, cb: (e: Record<string, number>) => void) => void }).on(
          'plotly_relayout',
          (e: Record<string, number>) => {
            const x0 = e['xaxis.range[0]'], x1 = e['xaxis.range[1]'];
            const y0 = e['yaxis.range[0]'], y1 = e['yaxis.range[1]'];
            if (x0 !== undefined && x1 !== undefined) {
              onViewportChange({ xMin: x0, xMax: x1, yMin: y0 ?? yMin, yMax: y1 ?? yMax });
            }
          }
        );
      } else {
        await Plotly.react(containerRef.current, traces, layout, config);
      }
    }
    void renderPlot();
  }, [data, onViewportChange]);

  useEffect(() => {
    return () => {
      async function cleanup() {
        if (containerRef.current && plotRef.current) {
          const Plotly: PlotlyModule = await import('plotly.js-dist-min');
          Plotly.purge(containerRef.current);
          plotRef.current = false;
        }
      }
      void cleanup();
    };
  }, []);

  return <div ref={containerRef} className="h-full w-full" style={{ minHeight: 300 }} />;
}

function FunctionRow({ fn, onUpdate, onRemove }: {
  fn: GraphFunction; onUpdate: (p: Partial<GraphFunction>) => void; onRemove: () => void;
}) {
  const t = useTranslations('features.graph');
  const [localExpr, setLocalExpr] = useState(fn.expression);
  const [hasError, setHasError] = useState(false);

  function commit() {
    const expr = preprocessExpression(localExpr);
    const { valid } = validateExpression(expr);
    setHasError(!valid && localExpr.trim().length > 0);
    if (valid) onUpdate({ expression: localExpr });
  }

  return (
    <div className="group flex items-center gap-1.5 rounded-lg border border-border bg-surface p-2">
      <label className="shrink-0 cursor-pointer">
        <input type="color" value={fn.color} onChange={(e) => onUpdate({ color: e.target.value })} className="sr-only" />
        <div className="h-5 w-5 rounded-full border-2 border-white/20 shadow" style={{ backgroundColor: fn.color }} />
      </label>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1">
          <span className="shrink-0 text-xs text-muted-foreground font-mono">y =</span>
          <input
            value={localExpr} onChange={(e) => setLocalExpr(e.target.value)}
            onBlur={commit} onKeyDown={(e) => { if (e.key === 'Enter') commit(); }}
            placeholder={t('expressionPlaceholder')}
            className={cn('flex-1 min-w-0 bg-transparent text-sm font-mono focus:outline-none',
              hasError ? 'text-destructive' : 'text-foreground')}
            spellCheck={false} />
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-0.5 opacity-0 transition-opacity group-hover:opacity-100">
        <button onClick={() => onUpdate({ visible: !fn.visible })}
          className="h-6 w-6 rounded flex items-center justify-center text-muted-foreground hover:bg-accent">
          {fn.visible ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
        </button>
        <button onClick={onRemove}
          className="h-6 w-6 rounded flex items-center justify-center text-muted-foreground hover:bg-destructive/10 hover:text-destructive">
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}

function AnalysisPanel({ data }: { data: GraphWorkspaceData }) {
  const t = useTranslations('features.graph');
  const [results, setResults] = useState<{ expr: string; roots: number[] }[]>([]);
  const [loading, setLoading] = useState(false);

  async function analyze() {
    setLoading(true);
    const { xMin, xMax } = data.viewport;
    const res: { expr: string; roots: number[] }[] = [];
    for (const fn of data.functions) {
      if (!fn.visible || !fn.expression.trim()) continue;
      try {
        const roots = findRoots(preprocessExpression(fn.expression), xMin, xMax);
        res.push({ expr: fn.expression, roots });
      } catch { /* skip */ }
    }
    setResults(res);
    setLoading(false);
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-muted-foreground">{t('analysis')}</span>
        <Button variant="outline" size="sm" onClick={() => void analyze()} disabled={loading} className="gap-1">
          <Search className="h-3 w-3" />{t('findRoots')}
        </Button>
      </div>
      {results.map(({ expr, roots }) => (
        <div key={expr} className="space-y-1">
          <p className="text-xs font-mono text-muted-foreground">y = {expr}</p>
          {roots.length > 0 ? (
            <div className="flex flex-wrap gap-1">
              {roots.map((r) => (
                <Badge key={r} variant="outline" className="font-mono text-[10px]">x = {formatValue(r, 4)}</Badge>
              ))}
            </div>
          ) : <p className="text-[11px] text-muted-foreground">{t('noRoots')}</p>}
        </div>
      ))}
    </div>
  );
}

export function GraphTool({ workspace }: { workspace: Workspace<'graph'> }) {
  const t = useTranslations('features.graph');
  const { updateWorkspaceData } = useWorkspaceStore();
  const data: GraphWorkspaceData = workspace.data;

  const updateData = useCallback(
    (patch: Partial<GraphWorkspaceData>) => {
      updateWorkspaceData(workspace.id, { ...data, ...patch });
    },
    [workspace.id, data, updateWorkspaceData]
  );

  const handleViewportChange = useCallback(
    (vp: GraphWorkspaceData['viewport']) => updateData({ viewport: vp }),
    [updateData]
  );

  function addFunction() {
    const fn: GraphFunction = {
      id: generateId(), expression: '',
      color: getNextColor(data.functions.map((f) => f.color)),
      visible: true, lineWidth: 2, lineStyle: 'solid',
    };
    updateData({ functions: [...data.functions, fn] });
  }

  return (
    <div className="feature-panel" style={{ flexDirection: 'row' }}>
      <div className="flex w-64 shrink-0 flex-col border-r border-border bg-surface">
        <div className="flex h-10 items-center justify-between border-b border-border px-3">
          <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t('functions')}</span>
          <Tooltip content={t('addFunction')} side="right">
            <Button variant="ghost" size="icon-sm" onClick={addFunction}><Plus className="h-4 w-4" /></Button>
          </Tooltip>
        </div>
        <ScrollArea className="flex-1">
          <div className="flex flex-col gap-2 p-3">
            {data.functions.length === 0 ? (
              <button onClick={addFunction}
                className="flex flex-col items-center gap-1.5 rounded-lg border border-dashed border-border py-6 text-muted-foreground hover:border-primary hover:text-primary">
                <Plus className="h-5 w-5" />
                <span className="text-xs">{t('addFunction')}</span>
              </button>
            ) : data.functions.map((fn) => (
              <FunctionRow key={fn.id} fn={fn}
                onUpdate={(p) => updateData({ functions: data.functions.map((f) => f.id === fn.id ? { ...f, ...p } : f) })}
                onRemove={() => updateData({ functions: data.functions.filter((f) => f.id !== fn.id) })}
              />
            ))}
          </div>
        </ScrollArea>
        <Separator />
        <div className="space-y-3 p-3">
          <div className="flex items-center justify-between">
            <Label>{t('grid')}</Label>
            <Switch checked={data.showGrid} onCheckedChange={(v) => updateData({ showGrid: v })} />
          </div>
          <div className="flex items-center justify-between">
            <Label>{t('axes')}</Label>
            <Switch checked={data.showAxes} onCheckedChange={(v) => updateData({ showAxes: v })} />
          </div>
          <Separator />
          <div className="grid grid-cols-2 gap-2">
            {(['xMin', 'xMax', 'yMin', 'yMax'] as const).map((key) => (
              <div key={key}>
                <Label className="mb-1">{t(key)}</Label>
                <Input type="number" value={data.viewport[key]}
                  onChange={(e) => updateData({ viewport: { ...data.viewport, [key]: Number(e.target.value) } })}
                  className="h-7 text-xs" />
              </div>
            ))}
          </div>
          <Button variant="outline" size="sm"
            onClick={() => updateData({ viewport: { xMin: -10, xMax: 10, yMin: -5, yMax: 5 } })}
            className="w-full gap-1">
            <RotateCcw className="h-3.5 w-3.5" />{t('reset')}
          </Button>
          <Separator />
          <AnalysisPanel data={data} />
        </div>
      </div>
      <div className="feature-canvas">
        <PlotlyCanvas data={data} onViewportChange={handleViewportChange} />
      </div>
    </div>
  );
}
