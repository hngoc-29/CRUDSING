'use client';

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { useRouter, usePathname } from 'next/navigation';
import { Moon, Sun, Monitor, Trash2, Shield } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogDescription, Tabs, TabsList, TabsTrigger, TabsContent,
} from '@/components/ui/composite';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/primitives';
import { Separator } from '@/components/ui/primitives';
import { useUIStore } from '@/store/ui-store';
import { useWorkspaceStore } from '@/store/workspace-store';
import { useTheme } from '@/hooks/use-theme';
import { db } from '@/lib/db';
import { cn } from '@/lib/utils';
import type { Theme } from '@/types';

// ─── Theme Selector ───────────────────────────────────────────────────────────

function ThemeSelector() {
  const t = useTranslations('settings');
  const { theme, setTheme } = useTheme();

  const options: Array<{ value: Theme; label: string; Icon: React.ElementType }> = [
    { value: 'light', label: t('light'), Icon: Sun },
    { value: 'dark',  label: t('dark'),  Icon: Moon },
    { value: 'system',label: t('system'), Icon: Monitor },
  ];

  return (
    <div className="flex gap-2">
      {options.map(({ value, label, Icon }) => (
        <button
          key={value}
          onClick={() => setTheme(value)}
          className={cn(
            'flex flex-1 flex-col items-center gap-1.5 rounded-lg border p-3 text-xs transition-colors',
            theme === value
              ? 'border-primary bg-primary/10 text-primary'
              : 'border-border bg-surface text-muted-foreground hover:bg-accent hover:text-foreground'
          )}
        >
          <Icon className="h-5 w-5" />
          {label}
        </button>
      ))}
    </div>
  );
}

// ─── Language Selector ────────────────────────────────────────────────────────

function LanguageSelector() {
  const t = useTranslations('settings');
  const router = useRouter();
  const pathname = usePathname();
  const currentLocale = pathname.startsWith('/en') ? 'en' : 'vi';

  function switchLocale(locale: string) {
    const segments = pathname.split('/');
    segments[1] = locale;
    router.push(segments.join('/') || `/${locale}`);
  }

  const langs = [
    { code: 'vi', label: t('vietnamese'), flag: '🇻🇳' },
    { code: 'en', label: t('english'), flag: '🇺🇸' },
  ];

  return (
    <div className="flex gap-2">
      {langs.map(({ code, label, flag }) => (
        <button
          key={code}
          onClick={() => switchLocale(code)}
          className={cn(
            'flex flex-1 items-center gap-2.5 rounded-lg border p-3 text-sm transition-colors',
            currentLocale === code
              ? 'border-primary bg-primary/10 text-primary'
              : 'border-border bg-surface text-muted-foreground hover:bg-accent hover:text-foreground'
          )}
        >
          <span className="text-lg">{flag}</span>
          {label}
        </button>
      ))}
    </div>
  );
}

// ─── Keyboard Shortcuts ───────────────────────────────────────────────────────

const SHORTCUTS = [
  { keys: ['Ctrl', 'Z'], desc: 'Undo' },
  { keys: ['Ctrl', 'Y'], desc: 'Redo' },
  { keys: ['Ctrl', 'Shift', 'E'], desc: 'Export' },
  { keys: ['Ctrl', '1-9'], desc: 'Switch workspace tab' },
  { keys: ['Delete'], desc: 'Delete selected (geometry)' },
  { keys: ['Alt', 'Drag'], desc: 'Pan view (geometry/graph)' },
  { keys: ['Scroll'], desc: 'Zoom in/out' },
  { keys: ['Enter'], desc: 'Confirm formula' },
  { keys: ['Esc'], desc: 'Cancel editing' },
];

function KeyboardShortcuts() {
  const t = useTranslations('settings');

  return (
    <div className="space-y-2">
      <Label className="block text-xs uppercase tracking-wide">{t('keyboardShortcuts')}</Label>
      <div className="rounded-lg border border-border overflow-hidden">
        {SHORTCUTS.map(({ keys, desc }, i) => (
          <div
            key={i}
            className={cn(
              'flex items-center justify-between px-3 py-2 text-sm',
              i > 0 && 'border-t border-border'
            )}
          >
            <span className="text-muted-foreground">{desc}</span>
            <div className="flex items-center gap-1">
              {keys.map((k, ki) => (
                <span key={ki}>
                  <kbd className="rounded border border-border bg-muted px-1.5 py-0.5 text-[11px] font-mono shadow-sm">
                    {k}
                  </kbd>
                  {ki < keys.length - 1 && <span className="mx-0.5 text-muted-foreground text-xs">+</span>}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── SettingsDialog ───────────────────────────────────────────────────────────

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const t = useTranslations('settings');
  const { clearAll: clearWorkspaces } = useWorkspaceStore();
  const [clearing, setClearing] = useState(false);
  const [clearConfirm, setClearConfirm] = useState(false);

  async function handleClearData() {
    if (!clearConfirm) {
      setClearConfirm(true);
      return;
    }
    setClearing(true);
    try {
      await db.clearAll();
      clearWorkspaces();
      onOpenChange(false);
    } finally {
      setClearing(false);
      setClearConfirm(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { onOpenChange(o); setClearConfirm(false); }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{t('title')}</DialogTitle>
          <DialogDescription>
            <span className="flex items-center gap-1.5">
              <Shield className="h-3.5 w-3.5 text-success" />
              {t('privacy')}
            </span>
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="appearance">
          <TabsList className="w-full">
            <TabsTrigger value="appearance" className="flex-1">{t('appearance')}</TabsTrigger>
            <TabsTrigger value="shortcuts" className="flex-1">{t('keyboardShortcuts')}</TabsTrigger>
            <TabsTrigger value="about" className="flex-1">{t('about')}</TabsTrigger>
          </TabsList>

          {/* Appearance */}
          <TabsContent value="appearance" className="space-y-6 pt-2">
            <div className="space-y-2">
              <Label>{t('theme')}</Label>
              <ThemeSelector />
            </div>

            <div className="space-y-2">
              <Label>{t('language')}</Label>
              <LanguageSelector />
            </div>

            <Separator />

            <div className="space-y-2">
              <Label className="text-destructive">{t('clearData')}</Label>
              <p className="text-xs text-muted-foreground">{t('clearDataConfirm')}</p>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => void handleClearData()}
                disabled={clearing}
                className="gap-1.5"
              >
                <Trash2 className="h-3.5 w-3.5" />
                {clearConfirm
                  ? 'Click again to confirm'
                  : clearing ? 'Clearing…' : t('clearData')}
              </Button>
            </div>
          </TabsContent>

          {/* Shortcuts */}
          <TabsContent value="shortcuts" className="pt-2">
            <KeyboardShortcuts />
          </TabsContent>

          {/* About */}
          <TabsContent value="about" className="space-y-4 pt-2">
            <div className="rounded-lg border border-border bg-surface p-4 space-y-3">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/15 text-primary text-xl font-bold">
                  ∑
                </div>
                <div>
                  <p className="font-semibold">MathSpace</p>
                  <p className="text-xs text-muted-foreground">{t('version')} 1.0.0</p>
                </div>
              </div>
              <Separator />
              <p className="text-xs text-muted-foreground leading-relaxed">
                A modern math workspace for Vietnamese high-school and university students.
                Supports graph plotting, variation tables, sign tables, geometry, formula editing,
                and table creation — all offline, all local.
              </p>
              <div className="flex flex-wrap gap-1.5 text-[10px]">
                {['Next.js 15', 'React 19', 'TypeScript', 'KaTeX', 'Plotly.js', 'Dexie.js', 'mathjs'].map((tech) => (
                  <span key={tech} className="rounded-full border border-border px-2 py-0.5 text-muted-foreground">
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-1.5 rounded-md border border-success/30 bg-success/5 p-3 text-xs text-success">
              <Shield className="h-3.5 w-3.5 shrink-0" />
              {t('privacy')}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
