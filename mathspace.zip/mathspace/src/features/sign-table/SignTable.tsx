'use client';

import { useState, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { Play, Download, AlertCircle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/primitives';
import { Label } from '@/components/ui/primitives';
import { Badge } from '@/components/ui/primitives';
import { ScrollArea } from '@/components/ui/composite';
import { Separator } from '@/components/ui/primitives';
import { useWorkspaceStore } from '@/store/workspace-store';
import { computeSignTable, signTableToSvg } from '@/lib/math/sign-table';
import { downloadFile } from '@/lib/utils';
import { formatValue } from '@/lib/math/parser';
import type { Workspace, SignTableWorkspaceData, SignTableData } from '@/types';

// ─── Sign Table SVG Renderer ──────────────────────────────────────────────────

function renderSignTableSVG(data: SignTableData): string {
  return signTableToSvg(data);
}

// ─── Inline SVG Sign Table ─────────────────────────────────────────────────────

function SignTableDisplay({ tableData }: { tableData: SignTableData }) {
  const { points, intervals } = tableData;

  const allXLabels = ['-∞', ...points.map((p) => formatValue(p.x, 4)), '+∞'];

  return (
    <div className="overflow-x-auto rounded-lg border border-border bg-white dark:bg-zinc-900 shadow-sm">
      <table className="border-collapse font-serif text-sm">
        <tbody>
          {/* x row */}
          <tr className="border-b border-border">
            <td className="w-14 border-r border-border px-3 py-2.5 font-semibold text-center">
              x
            </td>
            {allXLabels.map((label, idx) => {
              const point = idx > 0 && idx < allXLabels.length - 1 ? points[idx - 1] : null;
              return (
                <td
                  key={idx}
                  className={[
                    'px-4 py-2.5 text-center min-w-[72px]',
                    point ? 'font-bold text-foreground border-l border-border/50' : 'text-muted-foreground',
                  ].join(' ')}
                >
                  {label}
                </td>
              );
            })}
          </tr>

          {/* f(x) sign row */}
          <tr>
            <td className="w-14 border-r border-border px-3 py-3 font-semibold text-center">
              f(x)
            </td>
            {(() => {
              const cells: React.ReactNode[] = [];

              intervals.forEach((iv, i) => {
                // Sign in interval
                cells.push(
                  <td key={`iv-${i}`} className="px-4 py-3 text-center min-w-[72px]">
                    <span
                      className={[
                        'text-base font-bold',
                        iv.sign === '+' ? 'text-green-600' : iv.sign === '-' ? 'text-red-500' : 'text-muted-foreground',
                      ].join(' ')}
                    >
                      {iv.sign === '+' ? '+' : iv.sign === '-' ? '−' : iv.sign}
                    </span>
                  </td>
                );

                // Point separator (after each interval except last)
                if (i < points.length) {
                  const pt = points[i];
                  cells.push(
                    <td
                      key={`pt-${i}`}
                      className="border-l border-border/50 px-4 py-3 text-center min-w-[72px]"
                    >
                      <span
                        className={[
                          'text-sm font-bold',
                          pt?.type === 'pole' ? 'text-orange-500' : 'text-muted-foreground',
                        ].join(' ')}
                      >
                        {pt?.type === 'pole' ? '||' : '0'}
                      </span>
                    </td>
                  );
                }
              });

              return cells;
            })()}
          </tr>
        </tbody>
      </table>
    </div>
  );
}

// ─── Sign Table ───────────────────────────────────────────────────────────────

interface SignTableProps {
  workspace: Workspace<'sign-table'>;
}

export function SignTable({ workspace }: SignTableProps) {
  const t = useTranslations('features.signTable');
  const { updateWorkspaceData } = useWorkspaceStore();
  const data: SignTableWorkspaceData = workspace.data;
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateData = useCallback(
    (patch: Partial<SignTableWorkspaceData>) => {
      updateWorkspaceData(workspace.id, { ...data, ...patch });
    },
    [workspace.id, data, updateWorkspaceData]
  );

  async function handleCompute() {
    if (!data.expression.trim()) return;
    setLoading(true);
    setError(null);

    try {
      await new Promise((r) => setTimeout(r, 10));
      const result = computeSignTable(data.expression);
      if (!result) {
        setError(t('invalidExpression'));
      } else {
        updateData({ tableData: result });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : t('invalidExpression'));
    }

    setLoading(false);
  }

  function handleExportSVG() {
    if (!data.tableData) return;
    const svg = renderSignTableSVG(data.tableData);
    downloadFile(svg, `sign-table-${workspace.name || 'table'}.svg`, 'image/svg+xml');
  }

  return (
    <div className="feature-panel flex-row">
      {/* Left panel */}
      <div className="flex w-72 shrink-0 flex-col border-r border-border bg-surface">
        <div className="flex h-10 items-center border-b border-border px-3">
          <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            {t('title')}
          </span>
        </div>

        <ScrollArea className="flex-1">
          <div className="space-y-4 p-4">
            {/* Expression */}
            <div className="space-y-1.5">
              <Label>{t('expression')}</Label>
              <Input
                value={data.expression}
                onChange={(e) => updateData({ expression: e.target.value })}
                placeholder={t('expressionPlaceholder')}
                onKeyDown={(e) => { if (e.key === 'Enter') void handleCompute(); }}
                className="font-mono"
              />
              <p className="text-[11px] text-muted-foreground">
                Supports: polynomials, rational functions, products
              </p>
            </div>

            <Button
              onClick={() => void handleCompute()}
              disabled={loading || !data.expression.trim()}
              className="w-full gap-2"
            >
              <Play className="h-4 w-4" />
              {loading ? t('generating') : t('compute')}
            </Button>

            {error && (
              <div className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive">
                <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                {error}
              </div>
            )}

            {/* Results summary */}
            {data.tableData && (
              <>
                <Separator />

                {data.tableData.points.filter((p) => p.type === 'zero').length > 0 && (
                  <div>
                    <Label className="mb-1.5 block">{t('zeros')}</Label>
                    <div className="flex flex-wrap gap-1">
                      {data.tableData.points
                        .filter((p) => p.type === 'zero')
                        .map((p) => (
                          <Badge key={p.x} variant="outline" className="font-mono text-[10px]">
                            x = {formatValue(p.x, 4)}
                          </Badge>
                        ))}
                    </div>
                  </div>
                )}

                {data.tableData.points.filter((p) => p.type === 'pole').length > 0 && (
                  <div>
                    <Label className="mb-1.5 block">{t('poles')}</Label>
                    <div className="flex flex-wrap gap-1">
                      {data.tableData.points
                        .filter((p) => p.type === 'pole')
                        .map((p) => (
                          <Badge key={p.x} variant="destructive" className="font-mono text-[10px]">
                            x = {formatValue(p.x, 4)}
                          </Badge>
                        ))}
                    </div>
                  </div>
                )}

                <Separator />

                <Button variant="outline" size="sm" onClick={handleExportSVG} className="w-full gap-1.5">
                  <Download className="h-3.5 w-3.5" />
                  {t('exportSvg')}
                </Button>
              </>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Table area */}
      <div className="flex-1 overflow-auto p-6">
        {data.tableData ? (
          <div className="flex flex-col items-start gap-4">
            <SignTableDisplay tableData={data.tableData} />
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Info className="h-3.5 w-3.5" />
              <span>f(x) = {data.tableData.expression}</span>
            </div>
          </div>
        ) : (
          <div className="flex h-full items-center justify-center">
            <div className="max-w-sm text-center">
              <div className="mb-3 text-4xl">±</div>
              <p className="text-sm text-muted-foreground">{t('noTable')}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
