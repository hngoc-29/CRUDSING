'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import {
  Plus, Trash2, Merge, Download, AlignLeft,
  AlignCenter, AlignRight, Bold, Italic,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tooltip } from '@/components/ui/composite';
import { Separator } from '@/components/ui/primitives';
import { useWorkspaceStore } from '@/store/workspace-store';
import { cn, generateId, downloadFile } from '@/lib/utils';
import type { Workspace, TableWorkspaceData, TableCell, TableRow, CellType, Alignment } from '@/types';

// ─── KaTeX inline renderer ────────────────────────────────────────────────────

function MathCell({ content }: { content: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    async function render() {
      if (!ref.current) return;
      try {
        const katex = (await import('katex')).default;
        katex.render(content || '\\square', ref.current, {
          displayMode: false, throwOnError: false, output: 'html',
        });
      } catch {
        if (ref.current) ref.current.textContent = content;
      }
    }
    void render();
  }, [content]);
  return <span ref={ref} />;
}

// ─── Cell Component ───────────────────────────────────────────────────────────

interface CellProps {
  cell: TableCell;
  isSelected: boolean;
  onSelect: () => void;
  onChange: (patch: Partial<TableCell>) => void;
  width: number;
}

function CellComp({ cell, isSelected, onSelect, onChange, width }: CellProps) {
  const [editing, setEditing] = useState(false);
  const [localContent, setLocalContent] = useState(cell.content);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => { setLocalContent(cell.content); }, [cell.content]);

  function commitEdit() {
    setEditing(false);
    onChange({ content: localContent });
  }

  function startEdit() {
    setEditing(true);
    setTimeout(() => inputRef.current?.focus(), 10);
  }

  const Tag = cell.type === 'header' ? 'th' : 'td';

  return (
    <Tag
      style={{ width, minWidth: width, maxWidth: width }}
      className={cn(
        'relative select-none overflow-hidden border border-border p-1.5 transition-colors',
        'text-sm align-middle',
        cell.type === 'header' && 'bg-muted/40 font-semibold',
        cell.alignment === 'left' && 'text-left',
        cell.alignment === 'center' && 'text-center',
        cell.alignment === 'right' && 'text-right',
        cell.bold && 'font-bold',
        cell.italic && 'italic',
        isSelected && 'ring-2 ring-inset ring-primary',
        !editing && 'cursor-pointer hover:bg-accent/30'
      )}
      colSpan={cell.colSpan}
      rowSpan={cell.rowSpan}
      onClick={(e) => { e.stopPropagation(); onSelect(); }}
      onDoubleClick={startEdit}
    >
      {editing ? (
        <textarea
          ref={inputRef}
          value={localContent}
          onChange={(e) => setLocalContent(e.target.value)}
          onBlur={commitEdit}
          onKeyDown={(e) => { if (e.key === 'Escape') { setEditing(false); setLocalContent(cell.content); } if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); commitEdit(); } }}
          className="absolute inset-0 resize-none bg-surface px-1.5 py-1.5 text-sm font-mono focus:outline-none"
          rows={1}
        />
      ) : cell.type === 'math' && cell.content ? (
        <MathCell content={cell.content} />
      ) : (
        <span>{cell.content || '\u00A0'}</span>
      )}
    </Tag>
  );
}

// ─── Toolbar ──────────────────────────────────────────────────────────────────

interface TableToolbarProps {
  data: TableWorkspaceData;
  selectedCell: { row: number; col: number } | null;
  onAddRow: () => void;
  onAddCol: () => void;
  onDeleteRow: () => void;
  onDeleteCol: () => void;
  onSetAlignment: (alignment: Alignment) => void;
  onSetType: (type: CellType) => void;
  onToggleBold: () => void;
  onToggleItalic: () => void;
  onExport: () => void;
}

function TableToolbar({
  data, selectedCell, onAddRow, onAddCol, onDeleteRow, onDeleteCol,
  onSetAlignment, onSetType, onToggleBold, onToggleItalic, onExport,
}: TableToolbarProps) {
  const t = useTranslations('features.tableEditor');
  const cell = selectedCell
    ? data.rows[selectedCell.row]?.cells[selectedCell.col]
    : null;

  return (
    <div className="flex h-10 shrink-0 flex-wrap items-center gap-1 border-b border-border bg-surface px-3">
      <Tooltip content={t('addRow')}>
        <Button variant="ghost" size="icon-sm" onClick={onAddRow}><Plus className="h-3.5 w-3.5" /></Button>
      </Tooltip>
      <Tooltip content={t('addColumn')}>
        <Button variant="ghost" size="icon-sm" onClick={onAddCol}>
          <span className="flex"><Plus className="h-3.5 w-3.5" /><AlignCenter className="h-3.5 w-3.5 -ml-1" /></span>
        </Button>
      </Tooltip>

      <Separator orientation="vertical" className="h-5 mx-0.5" />

      <Tooltip content={t('deleteRow')}>
        <Button variant="ghost" size="icon-sm" onClick={onDeleteRow} disabled={!selectedCell}>
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </Tooltip>
      <Tooltip content={t('deleteColumn')}>
        <Button variant="ghost" size="icon-sm" onClick={onDeleteCol} disabled={!selectedCell}>
          <Trash2 className="h-3.5 w-3.5 rotate-90" />
        </Button>
      </Tooltip>

      <Separator orientation="vertical" className="h-5 mx-0.5" />

      {/* Alignment */}
      <Tooltip content={t('left')}>
        <Button
          variant={cell?.alignment === 'left' ? 'secondary' : 'ghost'}
          size="icon-sm"
          onClick={() => onSetAlignment('left')}
          disabled={!cell}
        >
          <AlignLeft className="h-3.5 w-3.5" />
        </Button>
      </Tooltip>
      <Tooltip content={t('center')}>
        <Button
          variant={cell?.alignment === 'center' ? 'secondary' : 'ghost'}
          size="icon-sm"
          onClick={() => onSetAlignment('center')}
          disabled={!cell}
        >
          <AlignCenter className="h-3.5 w-3.5" />
        </Button>
      </Tooltip>
      <Tooltip content={t('right')}>
        <Button
          variant={cell?.alignment === 'right' ? 'secondary' : 'ghost'}
          size="icon-sm"
          onClick={() => onSetAlignment('right')}
          disabled={!cell}
        >
          <AlignRight className="h-3.5 w-3.5" />
        </Button>
      </Tooltip>

      <Separator orientation="vertical" className="h-5 mx-0.5" />

      {/* Formatting */}
      <Tooltip content="Bold">
        <Button
          variant={cell?.bold ? 'secondary' : 'ghost'}
          size="icon-sm"
          onClick={onToggleBold}
          disabled={!cell}
        >
          <Bold className="h-3.5 w-3.5" />
        </Button>
      </Tooltip>
      <Tooltip content="Italic">
        <Button
          variant={cell?.italic ? 'secondary' : 'ghost'}
          size="icon-sm"
          onClick={onToggleItalic}
          disabled={!cell}
        >
          <Italic className="h-3.5 w-3.5" />
        </Button>
      </Tooltip>

      <Separator orientation="vertical" className="h-5 mx-0.5" />

      {/* Cell type */}
      {(['text', 'math', 'header'] as CellType[]).map((tp) => (
        <Tooltip key={tp} content={t(tp as Parameters<typeof t>[0])}>
          <Button
            variant={cell?.type === tp ? 'secondary' : 'ghost'}
            size="sm"
            onClick={() => onSetType(tp)}
            disabled={!cell}
            className="h-7 px-2 text-xs"
          >
            {tp === 'math' ? '∑' : tp === 'header' ? 'H' : 'T'}
          </Button>
        </Tooltip>
      ))}

      <div className="flex-1" />

      <Button variant="outline" size="sm" onClick={onExport} className="gap-1.5">
        <Download className="h-3.5 w-3.5" />
        LaTeX
      </Button>
    </div>
  );
}

// ─── LaTeX Export ─────────────────────────────────────────────────────────────

function tableToLatex(data: TableWorkspaceData): string {
  const colCount = data.rows[0]?.cells.length ?? 1;
  const colSpec = '|' + Array(colCount).fill('c').join('|') + '|';

  const rows = data.rows.map((row) => {
    const cells = row.cells.map((cell) => {
      let content = cell.content;
      if (cell.type === 'math') content = `$${content}$`;
      if (cell.bold) content = `\\textbf{${content}}`;
      if (cell.italic) content = `\\textit{${content}}`;
      if (cell.colSpan > 1) content = `\\multicolumn{${cell.colSpan}}{c}{${content}}`;
      return content;
    });
    return '  ' + cells.join(' & ') + ' \\\\';
  });

  return [
    '\\begin{tabular}{' + colSpec + '}',
    '  \\hline',
    rows.join('\n  \\hline\n'),
    '  \\hline',
    '\\end{tabular}',
  ].join('\n');
}

// ─── TableEditor ─────────────────────────────────────────────────────────────

interface TableEditorProps {
  workspace: Workspace<'table'>;
}

export function TableEditor({ workspace }: TableEditorProps) {
  const t = useTranslations('features.tableEditor');
  const { updateWorkspaceData } = useWorkspaceStore();
  const data: TableWorkspaceData = workspace.data;
  const [selectedCell, setSelectedCell] = useState<{ row: number; col: number } | null>(null);

  const updateData = useCallback(
    (patch: Partial<TableWorkspaceData>) => {
      updateWorkspaceData(workspace.id, { ...data, ...patch });
    },
    [workspace.id, data, updateWorkspaceData]
  );

  function updateCell(rowIdx: number, colIdx: number, patch: Partial<TableCell>) {
    const rows = data.rows.map((row, ri) => {
      if (ri !== rowIdx) return row;
      return {
        ...row,
        cells: row.cells.map((cell, ci) =>
          ci === colIdx ? { ...cell, ...patch } : cell
        ),
      };
    });
    updateData({ rows });
  }

  function getSelectedCell() {
    if (!selectedCell) return null;
    return data.rows[selectedCell.row]?.cells[selectedCell.col] ?? null;
  }

  function addRow() {
    const colCount = data.columnWidths.length;
    const newRow: TableRow = {
      id: generateId(),
      cells: Array.from({ length: colCount }, () => ({
        id: generateId(),
        content: '',
        type: 'text',
        alignment: 'center',
        colSpan: 1,
        rowSpan: 1,
        bold: false,
        italic: false,
      })),
    };
    updateData({ rows: [...data.rows, newRow] });
  }

  function addColumn() {
    const newWidth = 120;
    const rows = data.rows.map((row) => ({
      ...row,
      cells: [...row.cells, {
        id: generateId(),
        content: '',
        type: 'text' as CellType,
        alignment: 'center' as Alignment,
        colSpan: 1,
        rowSpan: 1,
        bold: false,
        italic: false,
      }],
    }));
    updateData({ rows, columnWidths: [...data.columnWidths, newWidth] });
  }

  function deleteRow() {
    if (!selectedCell || data.rows.length <= 1) return;
    const rows = data.rows.filter((_, i) => i !== selectedCell.row);
    updateData({ rows });
    setSelectedCell(null);
  }

  function deleteColumn() {
    if (!selectedCell || data.columnWidths.length <= 1) return;
    const ci = selectedCell.col;
    const rows = data.rows.map((row) => ({
      ...row,
      cells: row.cells.filter((_, i) => i !== ci),
    }));
    const columnWidths = data.columnWidths.filter((_, i) => i !== ci);
    updateData({ rows, columnWidths });
    setSelectedCell(null);
  }

  function setAlignment(alignment: Alignment) {
    if (!selectedCell) return;
    updateCell(selectedCell.row, selectedCell.col, { alignment });
  }

  function setCellType(type: CellType) {
    if (!selectedCell) return;
    updateCell(selectedCell.row, selectedCell.col, { type });
  }

  function toggleBold() {
    if (!selectedCell) return;
    const cell = getSelectedCell();
    updateCell(selectedCell.row, selectedCell.col, { bold: !cell?.bold });
  }

  function toggleItalic() {
    if (!selectedCell) return;
    const cell = getSelectedCell();
    updateCell(selectedCell.row, selectedCell.col, { italic: !cell?.italic });
  }

  function handleExport() {
    const latex = tableToLatex(data);
    downloadFile(latex, `table-${workspace.name || 'table'}.tex`, 'text/plain');
  }

  return (
    <div className="feature-panel" onClick={() => setSelectedCell(null)}>
      <TableToolbar
        data={data}
        selectedCell={selectedCell}
        onAddRow={addRow}
        onAddCol={addColumn}
        onDeleteRow={deleteRow}
        onDeleteCol={deleteColumn}
        onSetAlignment={setAlignment}
        onSetType={setCellType}
        onToggleBold={toggleBold}
        onToggleItalic={toggleItalic}
        onExport={handleExport}
      />

      {/* Table canvas */}
      <div className="flex-1 overflow-auto p-6">
        <div className="inline-block" onClick={(e) => e.stopPropagation()}>
          <table className="border-collapse shadow-sm">
            <tbody>
              {data.rows.map((row, ri) => (
                <tr key={row.id}>
                  {row.cells.map((cell, ci) => (
                    <CellComp
                      key={cell.id}
                      cell={cell}
                      isSelected={selectedCell?.row === ri && selectedCell?.col === ci}
                      onSelect={() => setSelectedCell({ row: ri, col: ci })}
                      onChange={(patch) => updateCell(ri, ci, patch)}
                      width={data.columnWidths[ci] ?? 120}
                    />
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={addRow} className="gap-1.5">
            <Plus className="h-3.5 w-3.5" />
            {t('addRow')}
          </Button>
          <Button variant="outline" size="sm" onClick={addColumn} className="gap-1.5">
            <Plus className="h-3.5 w-3.5" />
            {t('addColumn')}
          </Button>
          <span className="text-xs text-muted-foreground ml-2">
            Double-click to edit · Select math cell and type LaTeX
          </span>
        </div>
      </div>
    </div>
  );
}
