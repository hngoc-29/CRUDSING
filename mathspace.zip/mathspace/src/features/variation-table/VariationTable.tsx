'use client';

import { useState, useCallback, useRef } from 'react';
import { useTranslations } from 'next-intl';
import { Play, Download, AlertCircle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/primitives';
import { Label } from '@/components/ui/primitives';
import { Badge } from '@/components/ui/primitives';
import { ScrollArea } from '@/components/ui/composite';
import { Separator } from '@/components/ui/primitives';
import { useWorkspaceStore } from '@/store/workspace-store';
import { computeVariationTable } from '@/lib/math/variation-table';
import { downloadFile } from '@/lib/utils';
import { formatValue } from '@/lib/math/parser';
import type { Workspace, VariationTableWorkspaceData, VariationTableData } from '@/types';

// ─── SVG Variation Table Renderer ────────────────────────────────────────────

function renderVariationTableSVG(tableData: VariationTableData): string {
  const { criticalPoints, intervals, xValues, derivativeSigns } = tableData;

  // Columns: -∞, [gap, cp, gap] × N, +∞
  const colPoints = [null, ...criticalPoints.map((cp) => cp.x), null];
  const totalCols = colPoints.length;

  const ROW_H = 48;
  const COL_W = 90;
  const LABEL_W = 56;
  const totalW = LABEL_W + totalCols * COL_W;
  const totalH = 3 * ROW_H;

  const lines: string[] = [];

  // Background
  lines.push(`<rect width="${totalW}" height="${totalH}" fill="white" rx="4"/>`);

  // Outer border
  lines.push(`<rect width="${totalW}" height="${totalH}" fill="none" stroke="#334155" stroke-width="1.5" rx="4"/>`);

  // Horizontal lines
  for (let i = 1; i < 3; i++) {
    lines.push(`<line x1="0" y1="${i * ROW_H}" x2="${totalW}" y2="${i * ROW_H}" stroke="#334155" stroke-width="1"/>`);
  }

  // Vertical label separator
  lines.push(`<line x1="${LABEL_W}" y1="0" x2="${LABEL_W}" y2="${totalH}" stroke="#334155" stroke-width="1.5"/>`);

  // Vertical lines at critical points
  for (let i = 0; i < criticalPoints.length; i++) {
    const x = LABEL_W + (i + 1) * COL_W + COL_W / 2;
    lines.push(`<line x1="${x}" y1="0" x2="${x}" y2="${totalH}" stroke="#64748b" stroke-width="0.75" stroke-dasharray="4,3"/>`);
  }

  // Row labels
  const rowLabels = ['x', "f '(x)", 'f(x)'];
  rowLabels.forEach((label, i) => {
    lines.push(
      `<text x="${LABEL_W / 2}" y="${i * ROW_H + ROW_H / 2 + 5}" text-anchor="middle" font-family="serif" font-size="13" fill="#1e293b">${label}</text>`
    );
  });

  // ─── Row 1: x values ─────────────────────────────────────────────────────

  // -∞
  lines.push(`<text x="${LABEL_W + COL_W / 4}" y="${ROW_H / 2 + 5}" text-anchor="middle" font-family="serif" font-size="13" fill="#1e293b">-∞</text>`);

  // Critical point x values
  criticalPoints.forEach((cp, idx) => {
    const cx = LABEL_W + (idx + 1) * COL_W + COL_W / 2;
    const val = formatValue(cp.x, 3);
    lines.push(`<text x="${cx}" y="${ROW_H / 2 + 5}" text-anchor="middle" font-family="serif" font-size="13" font-weight="bold" fill="#1e293b">${val}</text>`);
  });

  // +∞
  const lastX = LABEL_W + totalCols * COL_W - COL_W / 4;
  lines.push(`<text x="${lastX}" y="${ROW_H / 2 + 5}" text-anchor="middle" font-family="serif" font-size="13" fill="#1e293b">+∞</text>`);

  // ─── Row 2: f'(x) signs ───────────────────────────────────────────────────

  let signIdx = 0;
  intervals.forEach((iv, idx) => {
    const colStart = LABEL_W + idx * COL_W;
    const midX = colStart + COL_W / 2;
    const sign = iv.increasing ? '+' : '−';
    const color = iv.increasing ? '#16a34a' : '#dc2626';
    lines.push(`<text x="${midX + COL_W / 4}" y="${ROW_H + ROW_H / 2 + 5}" text-anchor="middle" font-family="serif" font-size="16" fill="${color}">${sign}</text>`);

    if (idx < criticalPoints.length) {
      const cpColX = LABEL_W + (idx + 1) * COL_W + COL_W / 2;
      lines.push(`<text x="${cpColX}" y="${ROW_H + ROW_H / 2 + 5}" text-anchor="middle" font-family="serif" font-size="13" fill="#64748b">0</text>`);
    }
    signIdx++;
  });

  // ─── Row 3: f(x) values + arrows ─────────────────────────────────────────

  // Draw arrows for each interval
  intervals.forEach((iv, idx) => {
    const xStart = LABEL_W + idx * COL_W;
    const xEnd = LABEL_W + (idx + 1) * COL_W;
    const rowTop = 2 * ROW_H + 6;
    const rowBot = 3 * ROW_H - 6;

    if (iv.increasing) {
      // Arrow from bottom-left to top-right
      lines.push(`<line x1="${xStart + 10}" y1="${rowBot}" x2="${xEnd - 10}" y2="${rowTop}" stroke="#2563eb" stroke-width="1.5" marker-end="url(#arr)"/>`);
    } else {
      // Arrow from top-left to bottom-right
      lines.push(`<line x1="${xStart + 10}" y1="${rowTop}" x2="${xEnd - 10}" y2="${rowBot}" stroke="#2563eb" stroke-width="1.5" marker-end="url(#arr)"/>`);
    }
  });

  // f values at critical points
  criticalPoints.forEach((cp, idx) => {
    const cpX = LABEL_W + (idx + 1) * COL_W + COL_W / 2;
    const val = formatValue(cp.y, 3);
    const isMax = cp.type === 'max';
    const yPos = isMax ? 2 * ROW_H + 14 : 3 * ROW_H - 8;
    lines.push(`<text x="${cpX}" y="${yPos}" text-anchor="middle" font-family="serif" font-size="12" font-weight="bold" fill="${isMax ? '#dc2626' : '#16a34a'}">${val}</text>`);
  });

  const svgContent = [
    `<svg xmlns="http://www.w3.org/2000/svg" width="${totalW}" height="${totalH}" viewBox="0 0 ${totalW} ${totalH}">`,
    `<defs>`,
    `  <marker id="arr" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">`,
    `    <path d="M0,0 L6,3 L0,6 Z" fill="#2563eb"/>`,
    `  </marker>`,
    `</defs>`,
    ...lines,
    `</svg>`,
  ].join('\n');

  return svgContent;
}

// ─── VariationTable ───────────────────────────────────────────────────────────

interface VariationTableProps {
  workspace: Workspace<'variation-table'>;
}

export function VariationTable({ workspace }: VariationTableProps) {
  const t = useTranslations('features.variationTable');
  const { updateWorkspaceData } = useWorkspaceStore();
  const data: VariationTableWorkspaceData = workspace.data;
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const svgRef = useRef<HTMLDivElement>(null);

  const updateData = useCallback(
    (patch: Partial<VariationTableWorkspaceData>) => {
      updateWorkspaceData(workspace.id, { ...data, ...patch });
    },
    [workspace.id, data, updateWorkspaceData]
  );

  async function handleCompute() {
    if (!data.expression.trim()) return;
    setLoading(true);
    setError(null);

    try {
      await new Promise((r) => setTimeout(r, 10)); // allow UI to update
      const result = computeVariationTable(data.expression, data.xMin, data.xMax);
      if (!result) {
        setError(t('invalidExpression'));
      } else {
        updateData({ tableData: result });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : t('invalidExpression'));
    }

    setLoading(false);
  }

  function handleExportSVG() {
    if (!data.tableData) return;
    const svg = renderVariationTableSVG(data.tableData);
    downloadFile(svg, `bbt-${workspace.name || 'table'}.svg`, 'image/svg+xml');
  }

  return (
    <div className="feature-panel flex-row">
      {/* Left control panel */}
      <div className="flex w-72 shrink-0 flex-col border-r border-border bg-surface">
        <div className="flex h-10 items-center border-b border-border px-3">
          <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t('title')}</span>
        </div>

        <ScrollArea className="flex-1">
          <div className="space-y-4 p-4">
            {/* Expression */}
            <div className="space-y-1.5">
              <Label>{t('expression')}</Label>
              <Input
                value={data.expression}
                onChange={(e) => updateData({ expression: e.target.value })}
                placeholder={t('expressionPlaceholder')}
                onKeyDown={(e) => { if (e.key === 'Enter') void handleCompute(); }}
                className="font-mono"
              />
            </div>

            {/* Domain bounds (optional) */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label>{t('xMin')}</Label>
                <Input
                  type="number"
                  placeholder="-∞"
                  value={data.xMin ?? ''}
                  onChange={(e) => updateData({ xMin: e.target.value ? Number(e.target.value) : null })}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <Label>{t('xMax')}</Label>
                <Input
                  type="number"
                  placeholder="+∞"
                  value={data.xMax ?? ''}
                  onChange={(e) => updateData({ xMax: e.target.value ? Number(e.target.value) : null })}
                  className="text-xs"
                />
              </div>
            </div>

            <Button
              onClick={() => void handleCompute()}
              disabled={loading || !data.expression.trim()}
              className="w-full gap-2"
            >
              <Play className="h-4 w-4" />
              {loading ? t('generating') : t('compute')}
            </Button>

            {error && (
              <div className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive">
                <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                {error}
              </div>
            )}

            {/* Results */}
            {data.tableData && (
              <>
                <Separator />
                <div className="space-y-2.5">
                  <div>
                    <Label className="mb-1 block">{t('derivative')}</Label>
                    <code className="block rounded bg-surface-2 p-2 text-xs font-mono text-foreground">
                      f&apos;(x) = {data.tableData.derivative}
                    </code>
                  </div>

                  {data.tableData.criticalPoints.length > 0 && (
                    <div>
                      <Label className="mb-1.5 block">{t('criticalPoints')}</Label>
                      <div className="flex flex-wrap gap-1.5">
                        {data.tableData.criticalPoints.map((cp) => (
                          <Badge key={cp.x} variant={cp.type === 'max' ? 'destructive' : 'success'} className="font-mono text-[10px]">
                            {cp.type === 'max' ? '↑' : '↓'} x={formatValue(cp.x, 3)}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <Separator />

                <Button variant="outline" size="sm" onClick={handleExportSVG} className="w-full gap-1.5">
                  <Download className="h-3.5 w-3.5" />
                  {t('exportSvg')}
                </Button>
              </>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Table area */}
      <div className="flex-1 overflow-auto p-6">
        {data.tableData ? (
          <div className="flex flex-col items-start gap-4">
            <div
              ref={svgRef}
              dangerouslySetInnerHTML={{ __html: renderVariationTableSVG(data.tableData) }}
              className="drop-shadow-sm"
            />
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Info className="h-3.5 w-3.5" />
              <span>f(x) = {data.tableData.expression}</span>
            </div>
          </div>
        ) : (
          <div className="flex h-full items-center justify-center">
            <div className="max-w-sm text-center">
              <div className="mb-3 text-4xl">↗↘</div>
              <p className="text-sm text-muted-foreground">{t('noTable')}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
