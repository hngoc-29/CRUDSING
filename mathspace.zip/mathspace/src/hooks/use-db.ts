'use client';

import { useEffect, useRef, useCallback } from 'react';
import { useWorkspaceStore } from '@/store/workspace-store';
import { db } from '@/lib/db';

// ─── useDb Hook ───────────────────────────────────────────────────────────────

/**
 * Initializes workspaces from IndexedDB and auto-saves changes
 */
export function useDb() {
  const { workspaces, activeWorkspaceId, initialize } = useWorkspaceStore();
  const isInitialized = useRef(false);
  const prevWorkspacesRef = useRef(workspaces);

  // Load from DB on mount
  useEffect(() => {
    if (isInitialized.current) return;
    isInitialized.current = true;

    async function load() {
      try {
        const [savedWorkspaces, session] = await Promise.all([
          db.getAllWorkspaces(),
          db.getSession(),
        ]);

        initialize(savedWorkspaces, session?.activeWorkspaceId ?? null);
      } catch (err) {
        console.error('Failed to load from IndexedDB:', err);
        initialize([], null);
      }
    }

    void load();
  }, [initialize]);

  // Auto-save workspaces when they change
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const saveWorkspaces = useCallback(
    (() => {
      let timer: ReturnType<typeof setTimeout>;
      return (ws: typeof workspaces, activeId: string | null) => {
        clearTimeout(timer);
        timer = setTimeout(async () => {
          try {
            const prev = prevWorkspacesRef.current;
            const currIds = new Set(ws.map((w) => w.id));

            for (const workspace of ws) {
              const prevWs = prev.find((w) => w.id === workspace.id);
              if (!prevWs || prevWs.updatedAt !== workspace.updatedAt) {
                await db.saveWorkspace(workspace);
              }
            }

            for (const prevWs of prev) {
              if (!currIds.has(prevWs.id)) {
                await db.deleteWorkspace(prevWs.id);
              }
            }

            await db.saveSession(activeId, ws.map((w) => w.id));
            prevWorkspacesRef.current = ws;
          } catch (err) {
            console.error('Auto-save failed:', err);
          }
        }, 1000);
      };
    })(),
    []
  );

  useEffect(() => {
    const { initialized } = useWorkspaceStore.getState();
    if (!initialized) return;
    saveWorkspaces(workspaces, activeWorkspaceId);
  }, [workspaces, activeWorkspaceId, saveWorkspaces]);
}
