'use client';

import { useEffect, useCallback } from 'react';

type ModifierKeys = {
  ctrl?: boolean;
  meta?: boolean;
  shift?: boolean;
  alt?: boolean;
};

type HotkeyHandler = (event: KeyboardEvent) => void;

interface Hotkey {
  key: string;
  modifiers?: ModifierKeys;
  handler: HotkeyHandler;
  description?: string;
}

// ─── useHotkeys Hook ──────────────────────────────────────────────────────────

export function useHotkeys(hotkeys: Hotkey[], deps: unknown[] = []) {
  const handleKeyDown = useCallback(
    (event: KeyboardEvent) => {
      // Skip when typing in input fields
      const target = event.target as HTMLElement;
      const isInput =
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.isContentEditable;

      for (const hotkey of hotkeys) {
        const { key, modifiers = {}, handler } = hotkey;

        const ctrlMatch = modifiers.ctrl ? (event.ctrlKey || event.metaKey) : true;
        const metaMatch = modifiers.meta ? event.metaKey : true;
        const shiftMatch = modifiers.shift ? event.shiftKey : !event.shiftKey || !modifiers.shift;
        const altMatch = modifiers.alt ? event.altKey : true;
        const keyMatch = event.key.toLowerCase() === key.toLowerCase();

        if (keyMatch && ctrlMatch && metaMatch && altMatch) {
          // Allow Ctrl+Z, Ctrl+Y, etc. even in inputs
          const isGlobal = modifiers.ctrl || modifiers.meta;
          if (isInput && !isGlobal) continue;

          event.preventDefault();
          handler(event);
          return;
        }
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [...deps]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);
}

// ─── Predefined hotkey helpers ────────────────────────────────────────────────

export const HOTKEYS = {
  ctrl: (key: string, handler: HotkeyHandler, description?: string): Hotkey => ({
    key,
    modifiers: { ctrl: true },
    handler,
    description,
  }),
  ctrlShift: (key: string, handler: HotkeyHandler, description?: string): Hotkey => ({
    key,
    modifiers: { ctrl: true, shift: true },
    handler,
    description,
  }),
  plain: (key: string, handler: HotkeyHandler, description?: string): Hotkey => ({
    key,
    handler,
    description,
  }),
} as const;
