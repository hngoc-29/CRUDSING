import Dexie, { type EntityTable } from 'dexie';
import type { Workspace, WorkspaceType } from '@/types';

// ─── Database Schema ──────────────────────────────────────────────────────────

interface WorkspaceRecord {
  id: string;
  name: string;
  type: WorkspaceType;
  data: string; // JSON stringified
  createdAt: number; // timestamp
  updatedAt: number; // timestamp
}

interface SessionRecord {
  id: number;
  activeWorkspaceId: string | null;
  openWorkspaceIds: string[];
  updatedAt: number;
}

class MathSpaceDatabase extends Dexie {
  workspaces!: EntityTable<WorkspaceRecord, 'id'>;
  sessions!: EntityTable<SessionRecord, 'id'>;

  constructor() {
    super('MathSpaceDB');

    this.version(1).stores({
      workspaces: 'id, name, type, createdAt, updatedAt',
      sessions: '++id, updatedAt',
    });
  }
}

// ─── Singleton ────────────────────────────────────────────────────────────────

let dbInstance: MathSpaceDatabase | null = null;

function getDB(): MathSpaceDatabase {
  if (!dbInstance) {
    dbInstance = new MathSpaceDatabase();
  }
  return dbInstance;
}

// ─── Serialization ────────────────────────────────────────────────────────────

function serializeWorkspace(workspace: Workspace): WorkspaceRecord {
  return {
    id: workspace.id,
    name: workspace.name,
    type: workspace.type,
    data: JSON.stringify(workspace.data),
    createdAt: workspace.createdAt.getTime(),
    updatedAt: workspace.updatedAt.getTime(),
  };
}

function deserializeWorkspace(record: WorkspaceRecord): Workspace {
  return {
    id: record.id,
    name: record.name,
    type: record.type,
    data: JSON.parse(record.data),
    createdAt: new Date(record.createdAt),
    updatedAt: new Date(record.updatedAt),
  } as Workspace;
}

// ─── Database API ─────────────────────────────────────────────────────────────

export const db = {
  async getAllWorkspaces(): Promise<Workspace[]> {
    const records = await getDB().workspaces.orderBy('updatedAt').reverse().toArray();
    return records.map(deserializeWorkspace);
  },

  async getWorkspace(id: string): Promise<Workspace | null> {
    const record = await getDB().workspaces.get(id);
    return record ? deserializeWorkspace(record) : null;
  },

  async saveWorkspace(workspace: Workspace): Promise<void> {
    await getDB().workspaces.put(serializeWorkspace(workspace));
  },

  async deleteWorkspace(id: string): Promise<void> {
    await getDB().workspaces.delete(id);
  },

  async saveSession(activeId: string | null, openIds: string[]): Promise<void> {
    const db_ = getDB();
    const existing = await db_.sessions.orderBy('id').last();
    if (existing) {
      await db_.sessions.update(existing.id, {
        activeWorkspaceId: activeId,
        openWorkspaceIds: openIds,
        updatedAt: Date.now(),
      });
    } else {
      await db_.sessions.add({
        activeWorkspaceId: activeId,
        openWorkspaceIds: openIds,
        updatedAt: Date.now(),
      });
    }
  },

  async getSession(): Promise<{ activeWorkspaceId: string | null; openWorkspaceIds: string[] } | null> {
    const record = await getDB().sessions.orderBy('id').last();
    return record
      ? { activeWorkspaceId: record.activeWorkspaceId, openWorkspaceIds: record.openWorkspaceIds }
      : null;
  },

  async clearAll(): Promise<void> {
    await getDB().workspaces.clear();
    await getDB().sessions.clear();
  },
};
