import type {
  WorkspaceType,
  GraphWorkspaceData,
  FormulaWorkspaceData,
  VariationTableWorkspaceData,
  SignTableWorkspaceData,
  GeometryWorkspaceData,
  TableWorkspaceData,
  Workspace,
  TableRow,
} from '@/types';
import { generateId } from './utils';

// ─── Default Data Factories ───────────────────────────────────────────────────

export function defaultGraphData(): GraphWorkspaceData {
  return {
    functions: [
      {
        id: generateId(),
        expression: 'sin(x)',
        color: '#6366f1',
        visible: true,
        lineWidth: 2,
        lineStyle: 'solid',
      },
    ],
    viewport: { xMin: -10, xMax: 10, yMin: -5, yMax: 5 },
    showGrid: true,
    showAxes: true,
    showLegend: true,
    analysis: {},
  };
}

export function defaultFormulaData(): FormulaWorkspaceData {
  return {
    latex: '\\int_0^{+\\infty} e^{-x^2}\\,dx = \\frac{\\sqrt{\\pi}}{2}',
    displayMode: true,
    history: [],
  };
}

export function defaultVariationTableData(): VariationTableWorkspaceData {
  return {
    expression: 'x^2 - 3*x + 2',
    xMin: null,
    xMax: null,
    tableData: null,
    manualOverrides: {},
  };
}

export function defaultSignTableData(): SignTableWorkspaceData {
  return {
    expression: '(x - 1) * (x + 2)',
    tableData: null,
    manualOverrides: {},
  };
}

function makeDefaultRow(cols: number, isHeader = false): TableRow {
  return {
    id: generateId(),
    cells: Array.from({ length: cols }, () => ({
      id: generateId(),
      content: '',
      type: isHeader ? 'header' : 'text',
      alignment: 'center',
      colSpan: 1,
      rowSpan: 1,
      bold: isHeader,
      italic: false,
    })),
  };
}

export function defaultTableData(): TableWorkspaceData {
  const cols = 4;
  return {
    rows: [
      makeDefaultRow(cols, true),
      makeDefaultRow(cols),
      makeDefaultRow(cols),
      makeDefaultRow(cols),
    ],
    columnWidths: Array(cols).fill(120) as number[],
    showBorders: true,
    borderColor: '#e4e4e7',
    headerRow: true,
  };
}

export function defaultGeometryData(): GeometryWorkspaceData {
  return {
    shapes: [],
    showGrid: true,
    showAxes: true,
    snapToGrid: false,
    gridSize: 40,
    viewport: { x: 0, y: 0, scale: 1 },
    history: [],
    historyIndex: -1,
  };
}

// ─── Create Workspace ─────────────────────────────────────────────────────────

type DataMap = {
  graph: GraphWorkspaceData;
  formula: FormulaWorkspaceData;
  'variation-table': VariationTableWorkspaceData;
  'sign-table': SignTableWorkspaceData;
  geometry: GeometryWorkspaceData;
  table: TableWorkspaceData;
};

const defaultDataFactories: { [K in WorkspaceType]: () => DataMap[K] } = {
  graph: defaultGraphData,
  formula: defaultFormulaData,
  'variation-table': defaultVariationTableData,
  'sign-table': defaultSignTableData,
  geometry: defaultGeometryData,
  table: defaultTableData,
};

export function createWorkspace<T extends WorkspaceType>(
  type: T,
  name?: string
): Workspace<T> {
  const now = new Date();
  return {
    id: generateId(),
    name: name ?? '',
    type,
    data: defaultDataFactories[type]() as DataMap[T],
    createdAt: now,
    updatedAt: now,
  };
}
