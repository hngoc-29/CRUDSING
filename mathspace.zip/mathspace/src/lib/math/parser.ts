import * as math from 'mathjs';
import type { MathEvaluationResult } from '@/types';

// ─── Safe Evaluation ──────────────────────────────────────────────────────────

export function evaluateAt(expression: string, x: number): MathEvaluationResult {
  try {
    const scope = { x };
    const result = math.evaluate(expression, scope);
    const value = typeof result === 'number' ? result : Number(result);

    if (!isFinite(value)) {
      return { value: NaN, error: null };
    }
    return { value, error: null };
  } catch (err) {
    return { value: NaN, error: err instanceof Error ? err.message : 'Evaluation error' };
  }
}

// ─── Validate Expression ──────────────────────────────────────────────────────

export function validateExpression(expression: string): { valid: boolean; error: string | null } {
  try {
    math.parse(expression);
    evaluateAt(expression, 1);
    return { valid: true, error: null };
  } catch (err) {
    return { valid: false, error: err instanceof Error ? err.message : 'Invalid expression' };
  }
}

// ─── Symbolic Derivative ──────────────────────────────────────────────────────

export function computeDerivative(expression: string): string | null {
  try {
    const node = math.parse(expression);
    const derivative = math.derivative(node, 'x');
    return derivative.toString();
  } catch {
    return null;
  }
}

// ─── Numerical Root Finding ───────────────────────────────────────────────────

function bisectionRoot(
  expression: string,
  a: number,
  b: number,
  tolerance = 1e-10,
  maxIter = 100
): number | null {
  const fa = evaluateAt(expression, a).value;
  const fb = evaluateAt(expression, b).value;

  if (!isFinite(fa) || !isFinite(fb)) return null;
  if (Math.sign(fa) === Math.sign(fb)) return null;

  let lo = a;
  let hi = b;

  for (let i = 0; i < maxIter; i++) {
    const mid = (lo + hi) / 2;
    const fm = evaluateAt(expression, mid).value;

    if (!isFinite(fm)) return null;

    if (Math.abs(fm) < tolerance || (hi - lo) / 2 < tolerance) {
      return mid;
    }

    if (Math.sign(fm) === Math.sign(evaluateAt(expression, lo).value)) {
      lo = mid;
    } else {
      hi = mid;
    }
  }

  return (lo + hi) / 2;
}

export function findRoots(expression: string, xMin: number, xMax: number, samples = 1000): number[] {
  const roots: number[] = [];
  const step = (xMax - xMin) / samples;

  let prevX = xMin;
  let prevY = evaluateAt(expression, xMin).value;

  for (let i = 1; i <= samples; i++) {
    const currX = xMin + i * step;
    const currY = evaluateAt(expression, currX).value;

    if (isFinite(prevY) && isFinite(currY)) {
      // Sign change → root in [prevX, currX]
      if (Math.sign(prevY) !== Math.sign(currY) && prevY !== 0 && currY !== 0) {
        const root = bisectionRoot(expression, prevX, currX);
        if (root !== null) {
          // Avoid duplicate roots
          const isDuplicate = roots.some((r) => Math.abs(r - root) < 1e-6);
          if (!isDuplicate) {
            roots.push(Math.round(root * 1e8) / 1e8);
          }
        }
      }
      // Direct zero
      if (Math.abs(currY) < 1e-10) {
        const isDuplicate = roots.some((r) => Math.abs(r - currX) < 1e-6);
        if (!isDuplicate) {
          roots.push(currX);
        }
      }
    }

    prevX = currX;
    prevY = currY;
  }

  return roots.sort((a, b) => a - b);
}

// ─── Generate Plot Data ───────────────────────────────────────────────────────

export interface PlotSegment {
  x: number[];
  y: number[];
}

export function generatePlotData(
  expression: string,
  xMin: number,
  xMax: number,
  samples = 500
): PlotSegment[] {
  const segments: PlotSegment[] = [];
  let currentSegment: PlotSegment = { x: [], y: [] };

  const step = (xMax - xMin) / samples;

  for (let i = 0; i <= samples; i++) {
    const x = xMin + i * step;
    const { value: y } = evaluateAt(expression, x);

    if (isFinite(y) && !isNaN(y)) {
      currentSegment.x.push(x);
      currentSegment.y.push(y);
    } else {
      // Gap in the function - start new segment
      if (currentSegment.x.length > 1) {
        segments.push(currentSegment);
      }
      currentSegment = { x: [], y: [] };
    }
  }

  if (currentSegment.x.length > 1) {
    segments.push(currentSegment);
  }

  return segments;
}

// ─── Format Math Values ───────────────────────────────────────────────────────

export function formatValue(value: number | null, decimals = 4): string {
  if (value === null) return '';
  if (!isFinite(value)) return value > 0 ? '+∞' : '-∞';
  if (Math.abs(value) < 1e-10) return '0';

  const rounded = Math.round(value * 10 ** decimals) / 10 ** decimals;
  return rounded.toString();
}

export function formatValueLatex(value: number | null, decimals = 4): string {
  if (value === null) return '';
  if (!isFinite(value)) return value > 0 ? '+\\infty' : '-\\infty';
  if (Math.abs(value) < 1e-10) return '0';

  const rounded = Math.round(value * 10 ** decimals) / 10 ** decimals;

  // Try to express as simple fraction
  const tolerance = 1e-6;
  for (let denom = 2; denom <= 12; denom++) {
    const numer = Math.round(rounded * denom);
    if (Math.abs(numer / denom - rounded) < tolerance && numer !== 0) {
      if (numer % denom === 0) return (numer / denom).toString();
      return `\\frac{${numer}}{${denom}}`;
    }
  }

  return rounded.toString();
}

// ─── Preprocess Expression ────────────────────────────────────────────────────

/**
 * Normalize user input to mathjs-compatible expression
 * Handles common student notation like: 2x, sin x, x², etc.
 */
export function preprocessExpression(expr: string): string {
  return expr
    .trim()
    // Replace ^ with ^ (already correct for mathjs)
    // Handle implicit multiplication: 2x → 2*x, x(x+1) → x*(x+1)
    .replace(/(\d)([a-zA-Z(])/g, '$1*$2')
    .replace(/([a-zA-Z\)])(\d)/g, '$1*$2')
    .replace(/([a-zA-Z\)])(\()/g, '$1*$2')
    // Common substitutions
    .replace(/ln\s*\(/g, 'log(')
    .replace(/tg\s*\(/g, 'tan(')
    .replace(/ctg\s*\(/g, 'cot(')
    .replace(/\|([^|]+)\|/g, 'abs($1)');
}
