import type { SignTableData, SignPoint, SignInterval } from '@/types';
import { evaluateAt, findRoots, preprocessExpression } from './parser';

// ─── Detect Poles (Undefined Points) ─────────────────────────────────────────

function findPoles(expression: string, xMin: number, xMax: number): number[] {
  const poles: number[] = [];
  const samples = 2000;
  const step = (xMax - xMin) / samples;

  let prevVal = evaluateAt(expression, xMin).value;

  for (let i = 1; i <= samples; i++) {
    const x = xMin + i * step;
    const currVal = evaluateAt(expression, x).value;

    // Detect vertical asymptote: value jumps from large positive to large negative (or vice versa)
    if (isFinite(prevVal) && isFinite(currVal)) {
      if (Math.abs(currVal - prevVal) > 1e6 && Math.sign(currVal) !== Math.sign(prevVal)) {
        const poleX = xMin + (i - 0.5) * step;
        const isDuplicate = poles.some((p) => Math.abs(p - poleX) < 1e-4);
        if (!isDuplicate) poles.push(poleX);
      }
    } else if (!isFinite(currVal) && isFinite(prevVal)) {
      // Function becomes undefined
      const poleX = xMin + i * step;
      const isDuplicate = poles.some((p) => Math.abs(p - poleX) < 1e-4);
      if (!isDuplicate) poles.push(poleX);
    }

    prevVal = currVal;
  }

  // Try to find exact pole locations via denominator
  // Parse expression to find denominator zeros
  try {
    const denMatch = expression.match(/\/\s*\(([^)]+)\)/);
    if (denMatch?.[1]) {
      const denExpr = denMatch[1];
      const denRoots = findRoots(denExpr, xMin, xMax);
      for (const r of denRoots) {
        const isDuplicate = poles.some((p) => Math.abs(p - r) < 1e-4);
        if (!isDuplicate) poles.push(r);
      }
    }
  } catch {
    // Ignore denominator parsing errors
  }

  return poles.sort((a, b) => a - b);
}

// ─── Determine Sign in Interval ───────────────────────────────────────────────

function getSignInInterval(
  expression: string,
  from: number,
  to: number
): '+' | '-' | '0' {
  const samples = [0.1, 0.25, 0.5, 0.75, 0.9];

  for (const t of samples) {
    const x = from === -Infinity
      ? to - 10
      : to === Infinity
      ? from + 10
      : from + t * (to - from);

    const { value } = evaluateAt(expression, x);
    if (isFinite(value) && Math.abs(value) > 1e-10) {
      return value > 0 ? '+' : '-';
    }
  }

  return '0';
}

// ─── Main Computation ─────────────────────────────────────────────────────────

export function computeSignTable(rawExpression: string): SignTableData | null {
  const expression = preprocessExpression(rawExpression);

  // Validate
  const test = evaluateAt(expression, 1);
  if (test.error && !expression.includes('x')) return null;

  const xMin = -20;
  const xMax = 20;

  // Find zeros (numerator roots)
  const zeros = findRoots(expression, xMin, xMax);

  // Find poles (denominator roots / undefined points)
  const polesList = findPoles(expression, xMin, xMax);

  // Merge all special points
  const allPoints: SignPoint[] = [
    ...zeros.map((x) => ({ x, type: 'zero' as const })),
    ...polesList
      .filter((p) => !zeros.some((z) => Math.abs(z - p) < 1e-4))
      .map((x) => ({ x, type: 'pole' as const })),
  ].sort((a, b) => a.x - b.x);

  // Build intervals
  const sortedXValues = [-Infinity, ...allPoints.map((p) => p.x), Infinity];
  const intervals: SignInterval[] = [];

  for (let i = 0; i < sortedXValues.length - 1; i++) {
    const from = sortedXValues[i] ?? -Infinity;
    const to = sortedXValues[i + 1] ?? Infinity;

    const fromLabel =
      from === -Infinity ? '-∞' : from.toString();
    const toLabel =
      to === Infinity ? '+∞' : to.toString();

    // Check if boundary is a pole
    const fromPt = allPoints.find((p) => Math.abs(p.x - from) < 1e-8);
    const toPt = allPoints.find((p) => Math.abs(p.x - to) < 1e-8);

    const sign =
      fromPt?.type === 'pole' || toPt?.type === 'pole'
        ? getSignInInterval(expression, from === -Infinity ? from : from + 1e-8, to === Infinity ? to : to - 1e-8)
        : getSignInInterval(expression, from, to);

    intervals.push({
      from: from === -Infinity ? null : from,
      to: to === Infinity ? null : to,
      sign,
      fromLabel,
      toLabel,
    });
  }

  return {
    expression,
    points: allPoints,
    intervals,
  };
}

// ─── Sign Table to SVG ────────────────────────────────────────────────────────

export function signTableToSvg(data: SignTableData): string {
  const { points, intervals } = data;

  const colCount = points.length + 2; // -∞, points, +∞
  const cellW = 80;
  const cellH = 50;
  const rowH = 50;
  const labelW = 60;
  const totalW = labelW + colCount * cellW;
  const totalH = 2 * rowH + 20;

  const svgParts: string[] = [
    `<svg xmlns="http://www.w3.org/2000/svg" width="${totalW}" height="${totalH}" viewBox="0 0 ${totalW} ${totalH}">`,
    `<style>text { font-family: serif; font-size: 14px; } .label { font-weight: bold; }</style>`,
    `<rect width="${totalW}" height="${totalH}" fill="white" stroke="#333" stroke-width="1.5"/>`,

    // Row dividers
    `<line x1="0" y1="${rowH}" x2="${totalW}" y2="${rowH}" stroke="#333" stroke-width="1"/>`,
    `<line x1="${labelW}" y1="0" x2="${labelW}" y2="${totalH}" stroke="#333" stroke-width="1.5"/>`,

    // Row labels
    `<text x="${labelW / 2}" y="${rowH / 2 + 5}" text-anchor="middle" class="label">x</text>`,
    `<text x="${labelW / 2}" y="${rowH + rowH / 2 + 5}" text-anchor="middle" class="label">f(x)</text>`,
  ];

  // Column headers: -∞, points, +∞
  const headers = ['-∞', ...points.map((p) => (Math.round(p.x * 1000) / 1000).toString()), '+∞'];
  headers.forEach((h, idx) => {
    const x = labelW + idx * cellW + cellW / 2;
    svgParts.push(
      `<text x="${x}" y="${rowH / 2 + 5}" text-anchor="middle">${h}</text>`
    );
    if (idx > 0) {
      svgParts.push(
        `<line x1="${labelW + idx * cellW}" y1="0" x2="${labelW + idx * cellW}" y2="${totalH}" stroke="#ccc" stroke-width="0.5"/>`
      );
    }
  });

  // Point type indicators (0 for zero, || for pole)
  points.forEach((pt, idx) => {
    const x = labelW + (idx + 1) * cellW + cellW / 2;
    const indicator = pt.type === 'zero' ? '0' : '||';
    svgParts.push(
      `<text x="${x}" y="${rowH + rowH / 2 + 5}" text-anchor="middle" font-size="12">${indicator}</text>`
    );
    svgParts.push(
      `<line x1="${x}" y1="${rowH}" x2="${x}" y2="${totalH}" stroke="#333" stroke-width="${pt.type === 'pole' ? 1.5 : 0.5}"/>`
    );
  });

  // Interval signs
  intervals.forEach((interval, idx) => {
    // The interval sign is placed between two consecutive special x values
    const startCol = idx; // col index (0-based in the interval cells)
    const x = labelW + startCol * cellW + cellW * 0.5 + cellW / 2;

    // Clamp x inside svg bounds
    const safeX = Math.min(Math.max(x, labelW + 5), totalW - 5);
    const sign = interval.sign === '+' ? '+' : interval.sign === '-' ? '−' : '';
    svgParts.push(
      `<text x="${safeX}" y="${rowH + rowH / 2 + 5}" text-anchor="middle" font-size="16" fill="${interval.sign === '+' ? '#16a34a' : interval.sign === '-' ? '#dc2626' : '#666'}">${sign}</text>`
    );
  });

  svgParts.push('</svg>');
  return svgParts.join('\n');
}
