import type { VariationTableData, CriticalPoint, VariationInterval } from '@/types';
import {
  evaluateAt,
  computeDerivative,
  findRoots,
  formatValue,
  preprocessExpression,
} from './parser';

// ─── Domain Analysis ──────────────────────────────────────────────────────────

function analyzeDomain(expression: string): { min: number | null; max: number | null } {
  // For most functions in high-school context, domain is all reals
  // but we check for log, sqrt to adjust
  const lowerExpr = expression.toLowerCase();
  if (lowerExpr.includes('log(') || lowerExpr.includes('sqrt(') || lowerExpr.includes('ln(')) {
    return { min: 0.0001, max: null };
  }
  return { min: null, max: null };
}

// ─── Find Critical Points ─────────────────────────────────────────────────────

function findCriticalPoints(
  expression: string,
  derivative: string,
  xMin: number,
  xMax: number
): CriticalPoint[] {
  // Find where f'(x) = 0
  const derivRoots = findRoots(derivative, xMin, xMax, 2000);
  const criticalPoints: CriticalPoint[] = [];

  for (const x of derivRoots) {
    const { value: y } = evaluateAt(expression, x);
    if (!isFinite(y)) continue;

    // Determine max or min by checking sign change of f'
    const epsilon = 1e-6;
    const leftSign = evaluateAt(derivative, x - epsilon).value;
    const rightSign = evaluateAt(derivative, x + epsilon).value;

    let type: 'max' | 'min' = 'min';
    if (isFinite(leftSign) && isFinite(rightSign)) {
      if (leftSign > 0 && rightSign < 0) type = 'max';
      else if (leftSign < 0 && rightSign > 0) type = 'min';
    }

    criticalPoints.push({
      x: Math.round(x * 1e8) / 1e8,
      type,
      y: Math.round(y * 1e8) / 1e8,
    });
  }

  return criticalPoints.sort((a, b) => a.x - b.x);
}

// ─── Build Intervals ──────────────────────────────────────────────────────────

function buildIntervals(
  expression: string,
  derivative: string,
  xMin: number,
  xMax: number,
  criticalPoints: CriticalPoint[]
): VariationInterval[] {
  const intervals: VariationInterval[] = [];
  const boundaryPoints = [xMin, ...criticalPoints.map((cp) => cp.x), xMax];

  for (let i = 0; i < boundaryPoints.length - 1; i++) {
    const from = boundaryPoints[i] ?? xMin;
    const to = boundaryPoints[i + 1] ?? xMax;
    const mid = (from + to) / 2;

    const derivSign = evaluateAt(derivative, mid).value;
    const increasing = isFinite(derivSign) ? derivSign > 0 : false;

    const fromValue = evaluateAt(expression, from).value;
    const toValue = evaluateAt(expression, to).value;

    intervals.push({
      from: i === 0 ? null : from,
      to: i === boundaryPoints.length - 2 ? null : to,
      derivativeSign: increasing ? '+' : '-',
      increasing,
      fromValue: isFinite(fromValue) ? fromValue : null,
      toValue: isFinite(toValue) ? toValue : null,
    });
  }

  return intervals;
}

// ─── Main Computation ─────────────────────────────────────────────────────────

export function computeVariationTable(
  rawExpression: string,
  domainMin: number | null,
  domainMax: number | null
): VariationTableData | null {
  const expression = preprocessExpression(rawExpression);
  const derivative = computeDerivative(expression);

  if (!derivative) return null;

  const domain = analyzeDomain(expression);
  const effectiveMin = domainMin ?? domain.min ?? -10;
  const effectiveMax = domainMax ?? domain.max ?? 10;

  // Validate the expression evaluates correctly
  const testEval = evaluateAt(expression, (effectiveMin + effectiveMax) / 2);
  if (testEval.error) return null;

  const criticalPoints = findCriticalPoints(expression, derivative, effectiveMin, effectiveMax);
  const intervals = buildIntervals(expression, derivative, effectiveMin, effectiveMax, criticalPoints);

  // Build x-axis values for the table header row
  const xValues: Array<number | null> = [null]; // -∞
  for (const cp of criticalPoints) {
    xValues.push(cp.x);
  }
  xValues.push(null); // +∞

  // f' signs row
  const derivativeSigns: Array<'+' | '-' | '0'> = [];
  for (let i = 0; i < intervals.length; i++) {
    derivativeSigns.push(intervals[i]?.derivativeSign ?? '+');
    if (i < criticalPoints.length) {
      derivativeSigns.push('0');
    }
  }

  // f values row: alternating intervals and critical point values
  const fValues: Array<number | null> = [];

  // First interval start
  const firstInterval = intervals[0];
  if (firstInterval) {
    const startVal = evaluateAt(expression, effectiveMin + 0.001).value;
    fValues.push(isFinite(startVal) ? startVal : null);
  }

  for (let i = 0; i < criticalPoints.length; i++) {
    const cp = criticalPoints[i];
    if (cp) fValues.push(cp.y);
  }

  // Last interval end
  const lastInterval = intervals[intervals.length - 1];
  if (lastInterval) {
    const endVal = evaluateAt(expression, effectiveMax - 0.001).value;
    fValues.push(isFinite(endVal) ? endVal : null);
  }

  return {
    expression,
    derivative,
    domain: { min: domainMin, max: domainMax },
    criticalPoints,
    intervals,
    xValues,
    fValues,
    derivativeSigns,
  };
}

// ─── Variation Table to LaTeX ─────────────────────────────────────────────────

export function variationTableToLatex(data: VariationTableData): string {
  const { criticalPoints, intervals } = data;

  const xHeaders = criticalPoints.map((cp) => `, $${formatValue(cp.x)}$`).join('');

  return `\begin{tikzpicture}
\tkzTabInit{$x$ / 1, $f'(x)$ / 1, $f(x)$ / 2}{$-\infty$${xHeaders}, $+\infty$}
${intervals.map((iv) => `\tkzTabLine{, ${iv.increasing ? '+' : '-'},}`).join('\n')}
\end{tikzpicture}`;
}
