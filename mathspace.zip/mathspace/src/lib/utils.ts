import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// ─── cn ───────────────────────────────────────────────────────────────────────

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ─── Download Helpers ─────────────────────────────────────────────────────────

export function downloadFile(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export async function elementToPng(_element: HTMLElement): Promise<Blob | null> {
  // PNG export is handled per-feature via canvas.toDataURL()
  return null;
}

// ─── ID Generation ────────────────────────────────────────────────────────────

export function generateId(): string {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

// ─── Color Utilities ──────────────────────────────────────────────────────────

export const GRAPH_COLORS = [
  '#6366f1', // indigo
  '#ef4444', // red
  '#22c55e', // green
  '#f59e0b', // amber
  '#06b6d4', // cyan
  '#ec4899', // pink
  '#8b5cf6', // violet
  '#f97316', // orange
];

export function getNextColor(usedColors: string[]): string {
  for (const color of GRAPH_COLORS) {
    if (!usedColors.includes(color)) return color;
  }
  return GRAPH_COLORS[usedColors.length % GRAPH_COLORS.length] ?? GRAPH_COLORS[0] ?? '#6366f1';
}

// ─── Math Formatting ──────────────────────────────────────────────────────────

export function formatNumber(value: number, decimals = 4): string {
  if (!isFinite(value)) return value > 0 ? '+∞' : '-∞';
  if (Math.abs(value) < 1e-10) return '0';
  const factor = 10 ** decimals;
  return (Math.round(value * factor) / factor).toString();
}

// ─── Debounce ─────────────────────────────────────────────────────────────────

export function debounce<T extends (...args: unknown[]) => unknown>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout>;
  return (...args: Parameters<T>) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

// ─── Deep Clone ───────────────────────────────────────────────────────────────

export function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

// ─── Clamp ────────────────────────────────────────────────────────────────────

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

// ─── Workspace Display Helpers ────────────────────────────────────────────────

export const WORKSPACE_TYPE_LABELS: Record<string, { vi: string; en: string }> = {
  graph: { vi: 'Đồ thị', en: 'Graph' },
  formula: { vi: 'Công thức', en: 'Formula' },
  'variation-table': { vi: 'Bảng biến thiên', en: 'Variation Table' },
  'sign-table': { vi: 'Bảng xét dấu', en: 'Sign Table' },
  geometry: { vi: 'Hình học', en: 'Geometry' },
  table: { vi: 'Bảng', en: 'Table' },
};

export const WORKSPACE_TYPE_ICONS: Record<string, string> = {
  graph: 'TrendingUp',
  formula: 'Sigma',
  'variation-table': 'ArrowUpDown',
  'sign-table': 'PlusMinusIcon',
  geometry: 'Triangle',
  table: 'Table2',
};
