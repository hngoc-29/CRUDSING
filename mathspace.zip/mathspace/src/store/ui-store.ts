'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Theme } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

interface UIState {
  sidebarCollapsed: boolean;
  theme: Theme;
  activeToolPanel: string | null;
}

interface UIActions {
  setSidebarCollapsed: (collapsed: boolean) => void;
  toggleSidebar: () => void;
  setTheme: (theme: Theme) => void;
  setActiveToolPanel: (panel: string | null) => void;
}

type UIStore = UIState & UIActions;

// ─── Store ────────────────────────────────────────────────────────────────────

export const useUIStore = create<UIStore>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      theme: 'dark',
      activeToolPanel: null,

      setSidebarCollapsed(collapsed) {
        set({ sidebarCollapsed: collapsed });
      },

      toggleSidebar() {
        set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed }));
      },

      setTheme(theme) {
        set({ theme });
      },

      setActiveToolPanel(panel) {
        set({ activeToolPanel: panel });
      },
    }),
    {
      name: 'mathspace-ui',
      partialize: (state) => ({
        sidebarCollapsed: state.sidebarCollapsed,
        theme: state.theme,
      }),
    }
  )
);
