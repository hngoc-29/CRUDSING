'use client';

import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
import type { Workspace, WorkspaceType } from '@/types';
import { createWorkspace } from '@/lib/defaults';
import { generateId } from '@/lib/utils';

// ─── Types ────────────────────────────────────────────────────────────────────

interface WorkspaceState {
  workspaces: Workspace[];
  activeWorkspaceId: string | null;
  initialized: boolean;
}

interface WorkspaceActions {
  initialize: (workspaces: Workspace[], activeId: string | null) => void;
  addWorkspace: (type: WorkspaceType, name?: string) => string;
  removeWorkspace: (id: string) => void;
  updateWorkspaceData: (id: string, data: Workspace['data']) => void;
  updateWorkspaceName: (id: string, name: string) => void;
  setActiveWorkspace: (id: string) => void;
  getActiveWorkspace: () => Workspace | undefined;
  duplicateWorkspace: (id: string) => string | null;
  clearAll: () => void;
}

type WorkspaceStore = WorkspaceState & WorkspaceActions;

// ─── Store ────────────────────────────────────────────────────────────────────

export const useWorkspaceStore = create<WorkspaceStore>()(
  immer((set, get) => ({
    workspaces: [],
    activeWorkspaceId: null,
    initialized: false,

    initialize(workspaces, activeId) {
      set((state) => {
        state.workspaces = workspaces;
        state.activeWorkspaceId = activeId ?? workspaces[0]?.id ?? null;
        state.initialized = true;
      });
    },

    addWorkspace(type, name) {
      const workspace = createWorkspace(type, name);
      set((state) => {
        state.workspaces.unshift(workspace);
        state.activeWorkspaceId = workspace.id;
      });
      return workspace.id;
    },

    removeWorkspace(id) {
      set((state) => {
        const idx = state.workspaces.findIndex((w) => w.id === id);
        if (idx === -1) return;

        state.workspaces.splice(idx, 1);

        // Move active to adjacent workspace
        if (state.activeWorkspaceId === id) {
          const next = state.workspaces[idx] ?? state.workspaces[idx - 1];
          state.activeWorkspaceId = next?.id ?? null;
        }
      });
    },

    updateWorkspaceData(id, data) {
      set((state) => {
        const ws = state.workspaces.find((w) => w.id === id);
        if (!ws) return;
        ws.data = data as never;
        ws.updatedAt = new Date();
      });
    },

    updateWorkspaceName(id, name) {
      set((state) => {
        const ws = state.workspaces.find((w) => w.id === id);
        if (!ws) return;
        ws.name = name;
        ws.updatedAt = new Date();
      });
    },

    setActiveWorkspace(id) {
      set((state) => {
        state.activeWorkspaceId = id;
      });
    },

    getActiveWorkspace() {
      const { workspaces, activeWorkspaceId } = get();
      return workspaces.find((w) => w.id === activeWorkspaceId);
    },

    duplicateWorkspace(id) {
      const original = get().workspaces.find((w) => w.id === id);
      if (!original) return null;

      const duplicate: Workspace = {
        ...JSON.parse(JSON.stringify(original)) as Workspace,
        id: generateId(),
        name: `${original.name} (copy)`,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      set((state) => {
        const idx = state.workspaces.findIndex((w) => w.id === id);
        state.workspaces.splice(idx + 1, 0, duplicate);
        state.activeWorkspaceId = duplicate.id;
      });

      return duplicate.id;
    },

    clearAll() {
      set((state) => {
        state.workspaces = [];
        state.activeWorkspaceId = null;
      });
    },
  }))
);
