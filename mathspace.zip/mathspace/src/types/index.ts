// ─── Workspace Types ─────────────────────────────────────────────────────────

export type WorkspaceType =
  | 'graph'
  | 'formula'
  | 'variation-table'
  | 'sign-table'
  | 'geometry'
  | 'table';

export type Theme = 'light' | 'dark' | 'system';
export type Locale = 'vi' | 'en';

// ─── Graph Feature ────────────────────────────────────────────────────────────

export interface GraphFunction {
  id: string;
  expression: string;
  color: string;
  visible: boolean;
  lineWidth: number;
  lineStyle: 'solid' | 'dashed' | 'dotted';
}

export interface GraphViewport {
  xMin: number;
  xMax: number;
  yMin: number;
  yMax: number;
}

export interface GraphAnalysis {
  roots: number[];
  extrema: Array<{ x: number; y: number; type: 'max' | 'min' }>;
}

export interface GraphWorkspaceData {
  functions: GraphFunction[];
  viewport: GraphViewport;
  showGrid: boolean;
  showAxes: boolean;
  showLegend: boolean;
  analysis: Record<string, GraphAnalysis>;
}

// ─── Formula Feature ─────────────────────────────────────────────────────────

export interface FormulaWorkspaceData {
  latex: string;
  displayMode: boolean;
  history: string[];
}

// ─── Variation Table Feature ─────────────────────────────────────────────────

export interface CriticalPoint {
  x: number;
  type: 'max' | 'min';
  y: number;
}

export interface VariationInterval {
  from: number | null;
  to: number | null;
  derivativeSign: '+' | '-';
  fromValue: number | null;
  toValue: number | null;
  increasing: boolean;
}

export interface VariationTableData {
  expression: string;
  derivative: string;
  domain: { min: number | null; max: number | null };
  criticalPoints: CriticalPoint[];
  intervals: VariationInterval[];
  xValues: Array<number | null>;
  fValues: Array<number | null>;
  derivativeSigns: Array<'+' | '-' | '0'>;
}

export interface VariationTableWorkspaceData {
  expression: string;
  xMin: number | null;
  xMax: number | null;
  tableData: VariationTableData | null;
  manualOverrides: Record<string, string>;
}

// ─── Sign Table Feature ───────────────────────────────────────────────────────

export interface SignPoint {
  x: number;
  type: 'zero' | 'pole';
  label?: string;
}

export interface SignInterval {
  from: number | null;
  to: number | null;
  sign: '+' | '-' | '0' | '||';
  fromLabel: string;
  toLabel: string;
}

export interface SignTableData {
  expression: string;
  points: SignPoint[];
  intervals: SignInterval[];
}

export interface SignTableWorkspaceData {
  expression: string;
  tableData: SignTableData | null;
  manualOverrides: Record<string, string>;
}

// ─── Geometry Feature ─────────────────────────────────────────────────────────

export type GeometryToolType =
  | 'select'
  | 'point'
  | 'line'
  | 'segment'
  | 'ray'
  | 'circle'
  | 'polygon'
  | 'triangle'
  | 'vector';

export interface GeometryPoint {
  x: number;
  y: number;
}

export type GeometryShapeType =
  | 'point'
  | 'line'
  | 'segment'
  | 'ray'
  | 'circle'
  | 'polygon'
  | 'triangle'
  | 'vector';

export interface BaseShape {
  id: string;
  type: GeometryShapeType;
  label: string;
  color: string;
  visible: boolean;
  selected: boolean;
}

export interface PointShape extends BaseShape {
  type: 'point';
  x: number;
  y: number;
  size: number;
}

export interface LineShape extends BaseShape {
  type: 'line' | 'segment' | 'ray';
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

export interface CircleShape extends BaseShape {
  type: 'circle';
  cx: number;
  cy: number;
  radius: number;
}

export interface PolygonShape extends BaseShape {
  type: 'polygon' | 'triangle';
  points: GeometryPoint[];
}

export interface VectorShape extends BaseShape {
  type: 'vector';
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

export type GeometryShape =
  | PointShape
  | LineShape
  | CircleShape
  | PolygonShape
  | VectorShape;

export interface GeometryWorkspaceData {
  shapes: GeometryShape[];
  showGrid: boolean;
  showAxes: boolean;
  snapToGrid: boolean;
  gridSize: number;
  viewport: { x: number; y: number; scale: number };
  history: GeometryShape[][];
  historyIndex: number;
}

// ─── Table Editor Feature ─────────────────────────────────────────────────────

export type CellType = 'text' | 'math' | 'header';
export type Alignment = 'left' | 'center' | 'right';

export interface TableCell {
  id: string;
  content: string;
  type: CellType;
  alignment: Alignment;
  colSpan: number;
  rowSpan: number;
  bold: boolean;
  italic: boolean;
  backgroundColor?: string;
}

export interface TableRow {
  id: string;
  cells: TableCell[];
  height?: number;
}

export interface TableWorkspaceData {
  rows: TableRow[];
  columnWidths: number[];
  showBorders: boolean;
  borderColor: string;
  headerRow: boolean;
  caption?: string;
}

// ─── Workspace ────────────────────────────────────────────────────────────────

type WorkspaceDataMap = {
  graph: GraphWorkspaceData;
  formula: FormulaWorkspaceData;
  'variation-table': VariationTableWorkspaceData;
  'sign-table': SignTableWorkspaceData;
  geometry: GeometryWorkspaceData;
  table: TableWorkspaceData;
};

export interface Workspace<T extends WorkspaceType = WorkspaceType> {
  id: string;
  name: string;
  type: T;
  data: WorkspaceDataMap[T];
  createdAt: Date;
  updatedAt: Date;
}

// ─── Store Types ──────────────────────────────────────────────────────────────

export interface WorkspaceStore {
  workspaces: Workspace[];
  activeWorkspaceId: string | null;
  addWorkspace: (type: WorkspaceType, name?: string) => string;
  removeWorkspace: (id: string) => void;
  updateWorkspace: (id: string, data: Partial<Workspace>) => void;
  setActiveWorkspace: (id: string) => void;
  getActiveWorkspace: () => Workspace | null;
  duplicateWorkspace: (id: string) => void;
  reorderWorkspaces: (ids: string[]) => void;
}

export interface UIStore {
  sidebarCollapsed: boolean;
  theme: Theme;
  setSidebarCollapsed: (collapsed: boolean) => void;
  toggleSidebar: () => void;
  setTheme: (theme: Theme) => void;
}

// ─── Math Types ───────────────────────────────────────────────────────────────

export interface MathEvaluationResult {
  value: number;
  error: string | null;
}

export interface FunctionAnalysis {
  roots: number[];
  extrema: Array<{ x: number; y: number; type: 'max' | 'min' }>;
  derivative: string;
  domain: { min: number | null; max: number | null };
}
