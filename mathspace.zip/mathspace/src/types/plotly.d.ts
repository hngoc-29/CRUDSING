declare module 'plotly.js-dist-min' {
  import type Plotly from 'plotly.js';
  const PlotlyStatic: typeof Plotly;
  export = PlotlyStatic;
}
